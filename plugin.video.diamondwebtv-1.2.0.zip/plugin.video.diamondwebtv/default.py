# -*- coding: utf-8 -*-
import sys
import os
import json
import ssl
from urllib.parse import urlencode, parse_qsl
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# ---------------------------------------------------------------
# Η διεύθυνση του WordPress site σου. Αλλάζει μόνο εδώ, αν ποτέ
# αλλάξεις domain. Τα κανάλια διαβάζονται ΠΑΝΤΑ ζωντανά από το site.
# ---------------------------------------------------------------
SITE_URL = 'https://e-menucms.gr'

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE = os.path.join(PROFILE, 'channels_cache.json')
SAVED_SITE = os.path.join(PROFILE, 'site_url.txt')
API_PATH = '/wp-json/diamond-web-tv/v1/channels'
API_ALT = '/?rest_route=/diamond-web-tv/v1/channels'
UA = 'Kodi-DiamondWebTV/1.2'
TIMEOUT = 15

# ΣΠΟΡ FM TV: παίζει μόνο μέσα από την επίσημη εφαρμογή του (Google Play: gr.sportfmtv.app).
# Το κανάλι ανοίγει την εφαρμογή έξω από το Kodi· με το «Πίσω» του τηλεχειριστηρίου το Android
# γυρίζει στο Kodi (Sorbetto), στο σημείο που ήταν.
SPORTFM_PKG = 'gr.sportfmtv.app'
SPORTFM_NAME = 'ΣΠΟΡ FM TV'
SPORTFM_HOSTS = ('sportfmtv.gr',)


def log(msg):
    xbmc.log('[DiamondWebTV] %s' % msg, xbmc.LOGINFO)


def ensure_profile():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def get_site():
    """Επιστρέφει το site. Αν δεν έχει μπει στον κώδικα, ρωτάει μία φορά και το θυμάται."""
    if 'YOUR-SITE' not in SITE_URL:
        return SITE_URL
    try:
        with open(SAVED_SITE, 'r', encoding='utf-8') as f:
            s = f.read().strip()
            if s:
                return s
    except Exception:
        pass
    s = xbmcgui.Dialog().input('Διεύθυνση του WordPress site σου', type=xbmcgui.INPUT_ALPHANUM)
    if s:
        ensure_profile()
        with open(SAVED_SITE, 'w', encoding='utf-8') as f:
            f.write(s.strip())
    return s.strip() if s else ''


def build_candidates(site):
    site = (site or '').strip()
    if not site:
        return []
    if not site.startswith('http'):
        site = 'https://' + site
    site = site.rstrip('/')
    return [site + API_PATH, site + API_ALT]


def http_get_json(url):
    req = Request(url, headers={'User-Agent': UA, 'Accept': 'application/json',
                                'Cache-Control': 'no-cache'})
    with urlopen(req, timeout=TIMEOUT, context=ssl.create_default_context()) as r:
        return json.loads(r.read().decode('utf-8'))


def save_cache(data):
    try:
        ensure_profile()
        with open(CACHE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
    except Exception as e:
        log('cache write failed: %s' % e)


def load_cache():
    try:
        with open(CACHE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


def get_channels():
    cands = build_candidates(get_site())
    last_err = 'Δεν έχει οριστεί διεύθυνση site'
    for url in cands:
        try:
            data = http_get_json(url)
            if isinstance(data, list):
                save_cache(data)
                return data
        except Exception as e:
            last_err = e
            log('fetch failed %s: %s' % (url, e))
    cached = load_cache()
    if cached:
        xbmcgui.Dialog().notification('Diamond Web TV', 'Χωρίς σύνδεση με το site, εμφανίζεται η τελευταία λίστα',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        return cached
    xbmcgui.Dialog().ok('Diamond Web TV', 'Δεν φορτώθηκαν κανάλια.\n%s' % last_err)
    return []


def is_sportfm(url):
    """Κανάλι του καταλόγου που δείχνει στο sportfmtv.gr ανοίγει κι αυτό την επίσημη εφαρμογή."""
    host = url.split('://', 1)[-1].split('/', 1)[0].split('?', 1)[0].lower()
    return any(host == h or host.endswith('.' + h) for h in SPORTFM_HOSTS)


def app_installed(pkg):
    """Το Kodi στο Android δίνει τις εγκατεστημένες εφαρμογές στο androidapp://sources/apps/
    (AndroidAppDirectory.cpp)· κάθε αρχείο έχει όνομα το πακέτο της εφαρμογής."""
    try:
        files = xbmcvfs.listdir('androidapp://sources/apps/')[1]
    except Exception as e:
        log('app list failed: %s' % e)
        return True  # δεν ξέρουμε· δοκιμάζουμε να την ανοίξουμε
    return not files or pkg in files


def open_app(pkg, name):
    if not xbmc.getCondVisibility('System.Platform.Android'):
        xbmcgui.Dialog().ok(name, 'Το κανάλι ανοίγει μόνο σε Android box, μέσα από την επίσημη εφαρμογή του.')
        return
    if not app_installed(pkg):
        if xbmcgui.Dialog().yesno(name, 'Το κανάλι παίζει μέσα από την επίσημη εφαρμογή του, '
                                        'που δεν είναι εγκατεστημένη.\nΆνοιγμα του Google Play για εγκατάσταση;'):
            xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,market://details?id=%s)' % pkg)
        return
    xbmcgui.Dialog().notification(name, 'Ανοίγει η εφαρμογή· πάτα «Πίσω» για επιστροφή στο Sorbetto',
                                  xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin('StartAndroidActivity(%s)' % pkg)


def add_app_item(name, pkg, logo='', plot=''):
    li = xbmcgui.ListItem(label=name)
    art = logo or 'androidapp://sources/apps/%s.png' % pkg
    li.setArt({'thumb': art, 'icon': art, 'poster': art})
    info = li.getVideoInfoTag()
    info.setTitle(name)
    info.setPlot(plot or 'Ανοίγει την επίσημη εφαρμογή. Με το «Πίσω» γυρνάς στο Sorbetto.')
    li.setProperty('IsPlayable', 'false')
    link = '%s?%s' % (BASE, urlencode({'action': 'app', 'pkg': pkg, 'name': name}))
    xbmcplugin.addDirectoryItem(HANDLE, link, li, isFolder=False)


def list_channels():
    xbmcplugin.setContent(HANDLE, 'videos')
    channels = get_channels()
    if not any(is_sportfm(ch.get('url') or '') for ch in channels):
        add_app_item(SPORTFM_NAME, SPORTFM_PKG)
    for ch in channels:
        name = ch.get('name') or 'Χωρίς όνομα'
        url = ch.get('url') or ''
        if not url:
            continue
        logo = ch.get('logo') or ''
        if is_sportfm(url):
            add_app_item(name, SPORTFM_PKG, logo, ch.get('description') or '')
            continue
        li = xbmcgui.ListItem(label=name)
        if logo:
            li.setArt({'thumb': logo, 'icon': logo, 'poster': logo})
        info = li.getVideoInfoTag()
        info.setTitle(name)
        if ch.get('description'):
            info.setPlot(ch['description'])
        li.setProperty('IsPlayable', 'true')
        link = '%s?%s' % (BASE, urlencode({'action': 'play', 'url': url, 'name': name, 'logo': logo}))
        xbmcplugin.addDirectoryItem(HANDLE, link, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def play(url, name, logo):
    li = xbmcgui.ListItem(label=name, path=url)
    if logo:
        li.setArt({'thumb': logo, 'icon': logo})
    if url.split('|')[0].split('?')[0].lower().endswith('.mpd'):
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        li.setMimeType('application/dash+xml')
        li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def router(qs):
    p = dict(parse_qsl(qs))
    if p.get('action') == 'play':
        play(p.get('url', ''), p.get('name', ''), p.get('logo', ''))
    elif p.get('action') == 'app':
        open_app(p.get('pkg') or SPORTFM_PKG, p.get('name') or SPORTFM_NAME)
    else:
        list_channels()


if __name__ == '__main__':
    router(sys.argv[2][1:])
