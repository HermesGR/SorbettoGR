# -*- coding: utf-8 -*-
"""Sorbetto: φτηνοί (OEM) μοχλοί USB να δουλεύουν και μέσα στα παιχνίδια.

Τρέχει όταν ανοίγει η αρχική (Home.xml <onload>), γρήγορα και χωρίς τίποτα στην οθόνη.

Γιατί χρειάζεται (Kodi 21, platform/android/peripherals/AndroidJoystickState.cpp):
- Το Kodi φτιάχνει μόνο του αντιστοίχιση για κάθε νέο μοχλό από τα «τυποποιημένα» πλήκτρα
  του Android (A, B, X, Y, Start, βελάκια κ.λπ.) και τη σώζει στα buttonmaps του Joystick
  Support. Τα κουμπιά αριθμούνται με τη σειρά της λίστας ButtonKeycodes (39 θέσεις), όσα
  δηλώνει ότι έχει η συσκευή.
- Οι φτηνοί μοχλοί παίρνουν από το Android τον «γενικό» χάρτη (Generic.kl), που δηλώνει
  ΟΛΑ τα 39. Έτσι το Kodi δένει A/B/X/Y/Start και τον σταυρό σε κουμπιά που ο μοχλός δεν
  στέλνει ποτέ: στέλνει «Button 1…12» (θέσεις 23…34, που το Kodi δεν δένει σε τίποτα) και τον
  σταυρό ως άξονες. Στα μενού κουνιέται (οι άξονες είναι ο «αριστερός μοχλός» και κάνουν
  πλοήγηση), στο παιχνίδι όχι (π.χ. το SNES έχει μόνο σταυρό).

Τι κάνουμε, ΜΟΝΟ σε αρχεία με 39 κουμπιά που είναι ακόμα όπως τα έφτιαξε το Kodi (ο σταυρός
στα κουμπιά-βελάκια, θέση 18) και που δεν τα έχουμε ήδη αλλάξει:
- Σταυρός: στο ζευγάρι αξόνων που περισσεύει (ο σταυρός HAT, τελευταίοι δύο αδέσμευτοι
  άξονες)· αν δεν περισσεύει, στους άξονες του αριστερού μοχλού (ο μοχλός είναι σε ψηφιακή
  λειτουργία και αυτοί είναι ο σταυρός του) και ο «αριστερός μοχλός» βγαίνει.
- Κουμπιά: Button 1…12 με την πιο συνηθισμένη σειρά των USB μοχλών
  (1 X, 2 A, 3 B, 4 Y, 5 L1, 6 R1, 7 L2, 8 R2, 9 Select, 10 Start, 11 L3, 12 R3).
  Αν σε κάποιο μοντέλο βγουν ανακατεμένα, ο χρήστης τα αλλάζει από
  Ρυθμίσεις → Σύστημα → Είσοδος → Διαμόρφωση συνδεδεμένων χειριστηρίων (τότε το Kodi
  ξαναγράφει το αρχείο και εμείς δεν το ξαναπειράζουμε).
Οι μοχλοί Xbox/PlayStation και όσοι έχουν δικό τους χάρτη (λιγότερα από 39 κουμπιά) ΔΕΝ
αγγίζονται. Το Joystick Support ξαναδιαβάζει το αρχείο όταν το χρειαστεί (ButtonMap.cpp,
RESOURCE_LIFETIME 2″). Καταγραφή στο kodi.log με [Sorbetto Joystick].
"""
import os
import re
import xml.etree.ElementTree as ET

import xbmc
import xbmcvfs

MAPS = 'special://profile/addon_data/peripheral.joystick/resources/buttonmaps/xml/android/'
MARK = 'sorbetto-oem-fix 1'
GENERIC_BUTTONS = 39          # μέγεθος της λίστας ButtonKeycodes στο Kodi 21
DPAD_UP_INDEX = 18            # θέση του AKEYCODE_DPAD_UP όταν υπάρχουν και τα 39
BUTTON_1_INDEX = 23           # θέση του AKEYCODE_BUTTON_1 όταν υπάρχουν και τα 39
DEFAULT = 'game.controller.default'
OEM_ORDER = ['x', 'a', 'b', 'y', 'leftbumper', 'rightbumper', 'lefttrigger', 'righttrigger',
             'back', 'start', 'leftthumb', 'rightthumb']
# ό,τι το Kodi έδεσε σε «νεκρά» κουμπιά (θέσεις 0…22) και το ξαναδένουμε εμείς
DEAD_BUTTON_FEATURES = set(OEM_ORDER) | {'guide', 'up', 'down', 'left', 'right'}


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Sorbetto Joystick] %s' % msg, level)


def _axes_in(feature):
    """Δείκτες αξόνων που χρησιμοποιεί ένα feature (π.χ. axis="-1" -> 1)."""
    found = []
    for el in [feature] + list(feature):
        value = el.get('axis')
        if value:
            m = re.match(r'^[+-]?(\d+)$', value.strip())
            if m:
                found.append(int(m.group(1)))
    return found


def _stick_axes(feature):
    """(άξονας x, άξονας y) ενός μοχλού από τα <left>/<up>."""
    x = y = None
    for el in feature:
        value = (el.get('axis') or '').strip()
        m = re.match(r'^[+-]?(\d+)$', value)
        if not m:
            continue
        if el.tag in ('left', 'right'):
            x = int(m.group(1))
        elif el.tag in ('up', 'down'):
            y = int(m.group(1))
    return (x, y) if x is not None and y is not None else None


def fix(path):
    with open(path, encoding='utf-8') as fh:
        text = fh.read()
    if MARK in text:
        return False
    root = ET.fromstring(text)
    device = root.find('device')
    if device is None:
        return False
    try:
        buttons = int(device.get('buttoncount') or 0)
        axes = int(device.get('axiscount') or 0)
    except ValueError:
        return False
    if buttons != GENERIC_BUTTONS:
        return False  # μοχλός με δικό του χάρτη (Xbox, PlayStation …): δουλεύει ήδη
    ctrl = next((c for c in device.findall('controller') if c.get('id') == DEFAULT), None)
    if ctrl is None:
        return False
    feats = {f.get('name'): f for f in ctrl.findall('feature')}
    up = feats.get('up')
    if up is not None and up.get('button') != str(DPAD_UP_INDEX):
        return False  # ο σταυρός είναι ήδη αλλιώς (τον έφτιαξε ο χρήστης): δεν πειράζουμε

    # 1. σταυρός
    used = set()
    for f in ctrl.findall('feature'):
        used.update(_axes_in(f))
    free = [i for i in range(axes) if i not in used]
    left = feats.get('leftstick')
    if len(free) >= 2:
        dx, dy = free[-2], free[-1]
        how = 'στους άξονες %d/%d (σταυρός)' % (dx, dy)
    elif left is not None and _stick_axes(left):
        dx, dy = _stick_axes(left)
        ctrl.remove(left)
        how = 'στους άξονες του αριστερού μοχλού %d/%d' % (dx, dy)
    else:
        dx = dy = None
        how = 'χωρίς αλλαγή (δεν βρέθηκαν άξονες)'

    # 2. καθαρίζουμε ό,τι έδεσε το Kodi σε κουμπιά που ο μοχλός δεν στέλνει
    for f in list(ctrl.findall('feature')):
        b = f.get('button')
        if f.get('name') in DEAD_BUTTON_FEATURES and b is not None and b.isdigit() \
                and int(b) < BUTTON_1_INDEX:
            ctrl.remove(f)
    names = {f.get('name') for f in ctrl.findall('feature')}

    def add(name, **attrs):
        el = ET.SubElement(ctrl, 'feature', {'name': name})
        for k, v in attrs.items():
            el.set(k, v)

    if dx is not None:
        add('up', axis='-%d' % dy)
        add('down', axis='+%d' % dy)
        add('left', axis='-%d' % dx)
        add('right', axis='+%d' % dx)
    for n, name in enumerate(OEM_ORDER):
        if name not in names:  # π.χ. σκανδάλες σε άξονες μένουν όπως είναι
            add(name, button=str(BUTTON_1_INDEX + n))
    ctrl[:] = sorted(ctrl, key=lambda e: e.get('name') or '')

    out = ET.tostring(root, encoding='unicode')
    out = '<?xml version="1.0" ?>\n<!-- %s: Sorbetto, σταυρός και Button 1-12 για μοχλό OEM -->\n%s\n' % (MARK, out)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        fh.write(out)
    os.replace(tmp, path)
    log('%s: σταυρός %s, κουμπιά 1-12 -> %s' % (device.get('name'), how, ', '.join(OEM_ORDER)))
    return True


def run():
    folder = xbmcvfs.translatePath(MAPS)
    if not os.path.isdir(folder):
        return
    for name in sorted(os.listdir(folder)):
        if not name.endswith('.xml'):
            continue
        try:
            fix(os.path.join(folder, name))
        except Exception as exc:  # ένα χαλασμένο αρχείο δεν σταματά τα υπόλοιπα (μόνο στο αναλυτικό log,
            log('%s: %s' % (name, exc), xbmc.LOGDEBUG)  # αφού το script τρέχει σε κάθε άνοιγμα της αρχικής)


if __name__ == '__main__':
    run()
