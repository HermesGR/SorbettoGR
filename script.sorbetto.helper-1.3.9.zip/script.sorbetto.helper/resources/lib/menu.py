# -*- coding: utf-8 -*-
"""Κοινός κώδικας: λήψη, έλεγχος και τοπική αποθήκευση του μενού και των φόντων."""
import json
import os
import re

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('script.sorbetto.helper')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CACHE_FILE = os.path.join(PROFILE, 'menu.json')
BG_CACHE_FILE = os.path.join(PROFILE, 'backgrounds.json')
HIDDEN_FILE = os.path.join(PROFILE, 'hidden.json')
DEFAULT_FILE = os.path.join(ADDON_PATH, 'resources', 'default_menu.json')

ICONS = ('home', 'tv', 'mic', 'kid', 'ball', 'live', 'radio', 'film', 'music',
         'star', 'search', 'folder', 'play', 'globe', 'info', 'cog')

PROP_VERSION = 'sorbetto.menu.version'
PROP_BG_VERSION = 'sorbetto.bg.version'
PROP_HIDDEN = 'sorbetto.hidden'


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Sorbetto Helper] %s' % msg, level)


def lang():
    """'el' όταν το Kodi είναι στα Ελληνικά, αλλιώς 'en'."""
    return 'el' if xbmc.getLanguage(xbmc.ISO_639_1) == 'el' else 'en'


def _text(item, key, limit):
    value = item.get(key)
    return str(value)[:limit] if value else ''


def clean(data):
    """Κρατά μόνο ό,τι μοιάζει με σωστό μενού. Επιστρέφει None αν δεν είναι."""
    if not isinstance(data, dict):
        return None
    items = data.get('items')
    if not isinstance(items, list):
        return None
    out = []
    for item in items:
        if not isinstance(item, dict):
            continue
        label = item.get('label')
        if not isinstance(label, str) or not label.strip():
            continue
        icon = item.get('icon') if item.get('icon') in ICONS else 'folder'
        show = item.get('show') if item.get('show') in ('el', 'en') else ''
        out.append({
            'id': _text(item, 'id', 60),
            'label': label.strip()[:60],
            'label_en': _text(item, 'label_en', 60).strip(),
            'icon': icon,
            'action': _text(item, 'action', 500),
            'widget': _text(item, 'widget', 500),
            'widget_label': _text(item, 'widget_label', 80),
            'widget_label_en': _text(item, 'widget_label_en', 80),
            'description': _text(item, 'description', 300),
            'description_en': _text(item, 'description_en', 300),
            'show': show,
        })
    if not out:
        return None
    try:
        version = int(data.get('version') or 0)
    except (TypeError, ValueError):
        version = 0
    return {'version': version, 'items': out}


def clean_backgrounds(data):
    """Κρατά μόνο σωστές εγγραφές φόντων. Μια κενή λίστα είναι έγκυρη (ο διαχειριστής τα έσβησε όλα)."""
    if not isinstance(data, dict) or not isinstance(data.get('items'), list):
        return None
    items = []
    for bg in data['items']:
        if not isinstance(bg, dict):
            continue
        url = _text(bg, 'url', 1000)
        if not url.startswith('https://') and not url.startswith('http://'):
            continue
        thumb = _text(bg, 'thumb', 1000) or url
        items.append({
            'url': url,
            'thumb': thumb,
            'cat': _text(bg, 'cat', 60),
            'cat_en': _text(bg, 'cat_en', 60),
        })
    cats = []
    seen = set()
    for c in data.get('categories') or []:
        if isinstance(c, dict) and c.get('el') and c['el'] not in seen:
            seen.add(c['el'])
            cats.append({'el': str(c['el'])[:60], 'en': str(c.get('en') or c['el'])[:60]})
    try:
        version = int(data.get('version') or 0)
    except (TypeError, ValueError):
        version = 0
    return {'version': version, 'categories': cats, 'items': items}


def localized(item, key, current_lang):
    """Το αγγλικό πεδίο όταν το Kodi είναι στα Αγγλικά και υπάρχει, αλλιώς το ελληνικό."""
    if current_lang == 'en' and item.get(key + '_en'):
        return item[key + '_en']
    return item.get(key, '')


def item_key(item):
    """Σταθερό κλειδί κουμπιού για την απόκρυψη: το id του WordPress, αλλιώς το ελληνικό όνομα."""
    return item.get('id') or item.get('label', '')


_PROTECTED_ACTION = re.compile(r'ActivateWindow\(\s*(favourites|settings)\s*[,)]', re.I)


def is_protected(item):
    """Αγαπημένα και Ρυθμίσεις: πάντα ορατά, δεν κρύβονται ποτέ."""
    return item.get('id') in ('favourites', 'settings') or bool(_PROTECTED_ACTION.search(item.get('action', '')))


def load_hidden():
    """Τα κουμπιά που έκρυψε ΑΥΤΟΣ ο χρήστης (μόνο τοπικά, στο δικό του Kodi)."""
    try:
        with open(HIDDEN_FILE, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return {str(x) for x in data if isinstance(x, str)} if isinstance(data, list) else set()
    except (OSError, ValueError):
        return set()


def save_hidden(keys):
    save(sorted(keys), HIDDEN_FILE)


def read_json(path, cleaner):
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return cleaner(json.load(fh))
    except (OSError, ValueError) as exc:
        log('δεν διαβάστηκε %s: %s' % (path, exc), xbmc.LOGDEBUG)
        return None


def load():
    """Το μενού που δείχνουμε: πρώτα το τελευταίο που κατέβηκε, αλλιώς το ενσωματωμένο."""
    return read_json(CACHE_FILE, clean) or read_json(DEFAULT_FILE, clean) or {'version': 0, 'items': []}


def load_backgrounds():
    return read_json(BG_CACHE_FILE, clean_backgrounds) or {'version': 0, 'categories': [], 'items': []}


def save(data, path=None):
    path = path or CACHE_FILE
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(data, fh, ensure_ascii=False)
    os.replace(tmp, path)


def fetch(url, cleaner=clean, timeout=8):
    """Κατεβάζει JSON. Επιστρέφει None σε οποιοδήποτε πρόβλημα."""
    from urllib.request import Request, urlopen
    if not url.startswith('https://') and not url.startswith('http://'):
        return None
    try:
        req = Request(url, headers={'User-Agent': 'Sorbetto-Helper/1.2', 'Cache-Control': 'no-cache'})
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read(1024 * 1024)
        return cleaner(json.loads(raw.decode('utf-8')))
    except Exception as exc:  # χωρίς internet, λάθος διεύθυνση, χαλασμένο JSON
        log('η λήψη απέτυχε (%s): %s' % (url, exc), xbmc.LOGWARNING)
        return None


OLD_ZOOM_FONTS = {'6': 'SorbettoLarge', '12': 'SorbettoXLarge'}


def undo_old_zoom():
    """Μηδενίζει τη «Μεγέθυνση» που έβαζαν οι παλιές εκδόσεις (6 ή 12, σημάδι Skin.String(sorbetto_zoom)).
    Αγγίζει τη μεγέθυνση μόνο αν είναι ακόμα αυτή που βάλαμε εμείς (όχι ρύθμιση του χρήστη για overscan)."""
    mark = xbmc.getInfoLabel('Skin.String(sorbetto_zoom)')
    if mark not in OLD_ZOOM_FONTS:
        return False
    res = jsonrpc('Settings.GetSettingValue', {'setting': 'lookandfeel.skinzoom'})
    try:
        current = int((res.get('result') or {}).get('value', 0))
    except (TypeError, ValueError, AttributeError):
        current = None
    if current == int(mark):
        jsonrpc('Settings.SetSettingValue', {'setting': 'lookandfeel.skinzoom', 'value': 0})
    xbmc.executebuiltin('Skin.Reset(sorbetto_zoom)')
    return True


def migrate_old_zoom():
    """Μία φορά, στην εκκίνηση: όποιος είχε «Μεγάλο»/«Πολύ μεγάλο» με τη μεγέθυνση παίρνει το
    αντίστοιχο σετ γραμματοσειρών. Αν το skin δεν έχει ακόμα τα σετ (παλιό skin), δεν αλλάζει
    τίποτα και ξαναδοκιμάζει στην επόμενη εκκίνηση."""
    mark = xbmc.getInfoLabel('Skin.String(sorbetto_zoom)')
    if mark not in OLD_ZOOM_FONTS:
        return
    res = jsonrpc('Settings.SetSettingValue', {'setting': 'lookandfeel.font', 'value': OLD_ZOOM_FONTS[mark]})
    if res.get('result') is not True:
        log('μέγεθος γραμμάτων: το skin δεν έχει ακόμα τα νέα σετ, ξανά στην επόμενη εκκίνηση')
        return
    undo_old_zoom()
    log('μέγεθος γραμμάτων: από μεγέθυνση %s σε σετ %s' % (mark, OLD_ZOOM_FONTS[mark]))


def jsonrpc(method, params):
    req = json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})
    try:
        return json.loads(xbmc.executeJSONRPC(req))
    except ValueError:
        return {}
