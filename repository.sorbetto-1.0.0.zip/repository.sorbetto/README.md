# Sorbetto Repository (repository.sorbetto)

Αποθετήριο Kodi στο GitHub Pages: https://hermesgr.github.io/SorbettoGR/
Περιέχει: skin.sorbetto, script.sorbetto.helper.

## Εκδόσεις

### 1.0.0 — 14/10/2026
- Πρώτη έκδοση. Δείχνει στο https://hermesgr.github.io/SorbettoGR/ (addons.xml, addons.xml.md5, zip ανά πρόσθετο στο <id>/<id>-<έκδοση>.zip).
