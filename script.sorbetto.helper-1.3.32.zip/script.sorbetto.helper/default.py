# -*- coding: utf-8 -*-
"""Δίνει στο skin λίστες και εκτελεί μικρές εντολές.

Λίστες (το skin τις καλεί ως περιεχόμενο):
    ?action=menu      κουμπιά του μενού, στη γλώσσα του Kodi
    ?action=bgcats    κατηγορίες φόντων (πρώτη: «Όλα»)
    ?action=bgs&cat=N φόντα της κατηγορίας με αριθμό N (κενό = όλα· πρώτο: «Χωρίς φόντο»)
    ?action=apps      «Πρόσθετα»: εγκατεστημένες εφαρμογές (Netflix/Magenta/Nova) + «Όλα τα πρόσθετα»
    ?action=appswidget widget του «Πρόσθετα»: οι ίδιες εφαρμογές και μετά τα πρόσθετα βίντεο
    ?action=games      «Sorbetto Games»: τα παιχνίδια
    ?action=gameswidget widget του «Sorbetto Games»
Εντολές (το skin τις καλεί με RunPlugin):
    ?action=theme&name=<θέμα>   αλλαγή χρωμάτων
    ?action=zoom&v=<αριθμός>    μέγεθος γραμμάτων (μεγέθυνση του skin)
    ?action=zoomnext            μέγεθος γραμμάτων: Κανονικό -> Μεγάλο -> Πολύ μεγάλο (σετ γραμματοσειρών)
    ?action=langtoggle          Ελληνικά <-> English
    ?action=sections            ποιες ενότητες φαίνονται στην αρχική (ανά χρήστη)
    ?action=editor              επεξεργασία μενού (μόνο με κλειδί διαχειριστή)
    ?action=addons              κουμπί «Πρόσθετα»: λίστα εφαρμογών, ή κατευθείαν τα πρόσθετα αν δεν υπάρχει καμία
    ?action=openapp&pkg=<πακέτο> άνοιγμα εφαρμογής Android
    ?action=addonbrowser        τα πρόσθετα του Kodi
    ?action=game&id=<παιχνίδι>  άνοιγμα παιχνιδιού (λήψη αρχείων/εγκατάσταση την πρώτη φορά)
"""
import re
import sys
import time
from urllib.parse import parse_qsl

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import apps, games, menu

NOOP = 'plugin://script.sorbetto.helper/?action=noop'
ZOOM_ALLOWED = (0, 6, 12)
FONTSETS = ('Default', 'SorbettoLarge', 'SorbettoXLarge')


def add(handle, label, props, art=None):
    li = xbmcgui.ListItem(label=label, offscreen=True)
    li.setProperties(props)
    if art:
        li.setArt(art)
    xbmcplugin.addDirectoryItem(handle, NOOP, li, False)


def home_items():
    """Τα κουμπιά της αρχικής: του WordPress + «Sorbetto Games» (πρώην «Retro Gaming») πάνω από τα «Αγαπημένα»
    (αν δεν το έχει ήδη το μενού του WordPress). Δεν γράφεται στο WordPress."""
    items = list(menu.load()['items'])
    if any(i.get('id') == games.MENU_ID for i in items):
        return items
    pos = next((n for n, i in enumerate(items) if i.get('id') == 'favourites' or
                (menu.is_protected(i) and 'favourites' in i.get('action', '').lower())), None)
    if pos is None:
        pos = next((n for n, i in enumerate(items) if menu.is_protected(i)), len(items))
    items.insert(pos, dict(games.MENU_ITEM))
    return items


def effective_hidden():
    """Τα κρυμμένα κουμπιά. Το «Sorbetto Games» (πρώην «Retro Gaming») είναι ΚΡΥΜΜΕΝΟ από προεπιλογή (1.3.29): φαίνεται
    μόνο αν ο χρήστης το ανοίξει από «Ενότητες στην αρχική» (ρύθμιση retro_on = η εξαίρεση)."""
    hidden = menu.load_hidden()
    if not menu.ADDON.getSettingBool('retro_on'):
        hidden.add(games.MENU_ID)
    return hidden


def list_menu(handle):
    current = menu.lang()
    hidden = effective_hidden()
    for item in home_items():
        if item['show'] and item['show'] != current:
            continue
        if menu.item_key(item) in hidden and not menu.is_protected(item):
            continue
        add(handle, menu.localized(item, 'label', current), {
            'id': item['id'],
            'action': menu.fix_action(item['action']),
            'icon': item['icon'],
            'widget': menu.fix_widget(item['widget']),
            'widget_label': menu.localized(item, 'widget_label', current),
            'description': menu.localized(item, 'description', current),
        })
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_categories(handle):
    current = menu.lang()
    data = menu.load_backgrounds()
    add(handle, 'Όλα' if current == 'el' else 'All', {'cat': ''})
    for i, c in enumerate(data['categories'], 1):
        add(handle, c['el'] if current == 'el' else c['en'], {'cat': str(i)})
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_backgrounds(handle, cat):
    current = menu.lang()
    data = menu.load_backgrounds()
    chosen = xbmc.getInfoLabel('Skin.String(sorbetto_bg)')
    name = ''
    if cat.isdigit() and 0 < int(cat) <= len(data['categories']):
        name = data['categories'][int(cat) - 1]['el']
    add(handle, 'Χωρίς φόντο' if current == 'el' else 'No background',
        {'url': '', 'none': 'true', 'cur': 'true' if not chosen else ''})
    for bg in data['items']:
        if name and bg['cat'] != name:
            continue
        label = bg['cat'] if current == 'el' else (bg['cat_en'] or bg['cat'])
        add(handle, label, {'url': bg['url'], 'cur': 'true' if bg['url'] == chosen else ''},
            {'thumb': bg['thumb'], 'icon': bg['thumb']})
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def set_theme(name):
    if name != 'SKINDEFAULT' and not re.match(r'^[a-z0-9_]{1,40}$', name):
        return
    menu.jsonrpc('Settings.SetSettingValue', {'setting': 'lookandfeel.skincolors', 'value': name})


def set_zoom(value):
    try:
        value = int(value)
    except (TypeError, ValueError):
        return
    if value in ZOOM_ALLOWED:
        menu.jsonrpc('Settings.SetSettingValue', {'setting': 'lookandfeel.skinzoom', 'value': value})


def zoom_next():
    """«Μέγεθος γραμμάτων»: Κανονικό -> Μεγάλο -> Πολύ μεγάλο, με σετ γραμματοσειρών του skin
    (lookandfeel.font). ΔΕΝ χρησιμοποιούμε πια τη «Μεγέθυνση» (skinzoom): μεγεθύνει όλη την
    εικόνα και κόβει τις άκρες της οθόνης."""
    res = menu.jsonrpc('Settings.GetSettingValue', {'setting': 'lookandfeel.font'})
    current = (res.get('result') or {}).get('value', 'Default') if isinstance(res, dict) else 'Default'
    nxt = FONTSETS[(FONTSETS.index(current) + 1) % len(FONTSETS)] if current in FONTSETS else FONTSETS[1]
    menu.jsonrpc('Settings.SetSettingValue', {'setting': 'lookandfeel.font', 'value': nxt})
    menu.undo_old_zoom()


def lang_toggle():
    target = 'resource.language.en_gb' if menu.lang() == 'el' else 'resource.language.el_gr'
    xbmc.executebuiltin('SetGUILanguage(%s)' % target)


def choose_sections():
    """Ο χρήστης διαλέγει ποιες ενότητες φαίνονται στην αρχική. Τίποτα δεν διαγράφεται:
    τα κρυμμένα απλώς δεν μπαίνουν στη λίστα της αρχικής και ξαναφαίνονται με ένα τσεκ."""
    current = menu.lang()
    hidden = effective_hidden()
    items = [i for i in home_items()
             if not menu.is_protected(i) and (not i['show'] or i['show'] == current)]
    if not items:
        xbmcgui.Dialog().ok(menu.ADDON.getLocalizedString(30011), menu.ADDON.getLocalizedString(30013))
        return
    labels = [menu.localized(i, 'label', current) for i in items]
    pre = [n for n, i in enumerate(items) if menu.item_key(i) not in hidden]
    chosen = xbmcgui.Dialog().multiselect(menu.ADDON.getLocalizedString(30011), labels, preselect=pre)
    if chosen is None:  # «Άκυρο»: καμία αλλαγή
        return
    keys = {menu.item_key(i) for i in items}
    shown = {menu.item_key(items[n]) for n in chosen}
    new_hidden = (hidden - keys) | (keys - shown)
    # «Retro Gaming»: κρατιέται ως εξαίρεση στη ρύθμιση retro_on, όχι στο hidden.json
    if games.MENU_ID in keys:
        menu.ADDON.setSettingBool('retro_on', games.MENU_ID in shown)
    new_hidden.discard(games.MENU_ID)
    menu.save_hidden(new_hidden)
    # η αρχική ξαναφορτώνει το μενού (αλλάζει η διεύθυνση της λίστας)
    xbmcgui.Window(10000).setProperty(menu.PROP_HIDDEN, str(int(time.time() * 1000)))
    xbmcgui.Dialog().notification('Sorbetto', menu.ADDON.getLocalizedString(30012), time=2500, sound=False)


APPS_LIST = 'plugin://script.sorbetto.helper/?action=apps'


def open_addons():
    """Κουμπί «Πρόσθετα»: αν υπάρχει έστω μία εφαρμογή, η λίστα· αλλιώς κατευθείαν τα πρόσθετα."""
    if apps.installed():
        xbmc.executebuiltin('ActivateWindow(Programs,"%s",return)' % APPS_LIST)
    else:
        xbmc.executebuiltin('ActivateWindow(AddonBrowser)')


def list_apps(handle):
    xbmcplugin.setPluginCategory(handle, menu.ADDON.getLocalizedString(30016))
    for app in apps.installed():
        li = xbmcgui.ListItem(label=app['label'], offscreen=True)
        li.setArt({'icon': app['icon'], 'thumb': app['icon']})
        li.setProperty('IsPlayable', 'false')
        li.getVideoInfoTag().setPlot(menu.ADDON.getLocalizedString(30020 if app.get('missing') else 30018))
        xbmcplugin.addDirectoryItem(handle, 'plugin://script.sorbetto.helper/?action=openapp&pkg=%s' % app['pkg'],
                                    li, False)
    li = xbmcgui.ListItem(label=menu.ADDON.getLocalizedString(30017), offscreen=True)
    li.setArt({'icon': 'DefaultAddon.png', 'thumb': 'DefaultAddon.png'})
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(handle, 'plugin://script.sorbetto.helper/?action=addonbrowser', li, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_apps_widget(handle):
    """Στο widget ο σύνδεσμος androidapp:// ανοίγει την εφαρμογή (ExecString.cpp → StartAndroidActivity)."""
    for app in apps.installed():
        li = xbmcgui.ListItem(label=app['label'], offscreen=True)
        li.setArt({'icon': app['icon'], 'thumb': app['icon'], 'poster': app['icon']})
        if app.get('missing'):  # δεν είναι εγκατεστημένη: ο βοηθός ρωτά για εγκατάσταση
            path = menu.favourite_url('plugin://script.sorbetto.helper/?action=openapp&pkg=%s' % app['pkg'])
        else:
            path = apps.APP_DIR + app['pkg']
        xbmcplugin.addDirectoryItem(handle, path, li, False)
    for addon in apps.video_addons():
        li = xbmcgui.ListItem(label=addon.get('name') or addon['addonid'], offscreen=True)
        thumb = addon.get('thumbnail') or 'DefaultAddon.png'
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb})
        xbmcplugin.addDirectoryItem(handle, 'plugin://%s/' % addon['addonid'], li, True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_games(handle):
    xbmcplugin.setPluginCategory(handle, games.t('title'))
    for game in games.entries(with_all=True):
        li = xbmcgui.ListItem(label=game['label'], offscreen=True)
        li.setArt({'icon': game['thumb'], 'thumb': game['thumb'], 'poster': game['thumb'], 'fanart': game['fanart']})
        li.setProperty('IsPlayable', 'false')
        li.getVideoInfoTag().setPlot(game['plot'])
        xbmcplugin.addDirectoryItem(handle, games.GAME_URL % game['id'], li, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_games_widget(handle):
    """Στο widget κάθε παιχνίδι είναι «αγαπημένο» με την εντολή RunPlugin: ανοίγει με ένα κλικ."""
    for game in games.entries():
        li = xbmcgui.ListItem(label=game['label'], offscreen=True)
        li.setArt({'icon': game['thumb'], 'thumb': game['thumb'], 'poster': game['thumb']})
        xbmcplugin.addDirectoryItem(handle, games.favourite_path(game['id']), li, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def main():
    handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action', 'menu')

    if action == 'theme':
        set_theme(params.get('name', ''))
    elif action == 'zoom':
        set_zoom(params.get('v'))
    elif action == 'zoomnext':
        zoom_next()
    elif action == 'langtoggle':
        lang_toggle()
    elif action == 'sections':
        choose_sections()
    elif action == 'editor':
        from resources.lib import editor
        editor.run()
    elif action == 'addons':
        open_addons()
    elif action == 'openapp':
        apps.start(params.get('pkg', ''))
    elif action == 'addonbrowser':
        xbmc.executebuiltin('ActivateWindow(AddonBrowser)')
    elif action == 'game':
        if handle >= 0:  # κλήση για αναπαραγωγή: δεν παίζουμε βίντεο, ανοίγουμε το παιχνίδι
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))
        games.play(params.get('id', ''))
    elif handle < 0:
        xbmc.log('[Sorbetto Helper] άγνωστη εντολή: %s' % action, xbmc.LOGDEBUG)
    elif action == 'menu':
        list_menu(handle)
    elif action == 'bgcats':
        list_categories(handle)
    elif action == 'bgs':
        list_backgrounds(handle, params.get('cat', ''))
    elif action == 'apps':
        list_apps(handle)
    elif action == 'appswidget':
        list_apps_widget(handle)
    elif action == 'games':
        list_games(handle)
    elif action == 'gameswidget':
        list_games_widget(handle)
    else:
        # Τα κουμπιά εκτελούνται από το skin· εδώ δεν κάνουμε τίποτα.
        xbmcplugin.endOfDirectory(handle, succeeded=False)


if __name__ == '__main__':
    main()
