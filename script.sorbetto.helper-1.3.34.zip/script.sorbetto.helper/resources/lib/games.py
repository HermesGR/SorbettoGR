# -*- coding: utf-8 -*-
"""«Sorbetto Games» (από 1.3.30, πρώην «Retro Gaming»).

Τα παιχνίδια είναι:
- τα παιχνίδια του πρόσθετου SorbettoGames (plugin.program.sorbetto.games, αποθετήριο
  repository.sorbetto.games). Η λίστα διαβάζεται από τον κατάλογο του ίδιου του πρόσθετου
  (resources/catalog.json), οπότε ό,τι προστεθεί εκεί εμφανίζεται μόνο του και εδώ.
- το Rick Dangerous (game.libretro.xrick, επίσημο πρόσθετο του Kodi, εξάρτηση του βοηθού).

Το SorbettoGames εγκαθίσταται με το πρώτο κλικ: πρώτα το αποθετήριό του (υπάρχει στο SorbettoGR),
μετά το πρόσθετο από το δικό του αποθετήριο. Το Sorbetto Repository ΔΕΝ δείχνει στο SorbettoGames:
στο Kodi, αν αποτύχει μία από τις πηγές ενός αποθετηρίου, σταματά όλο (Repository.cpp,
FetchIfChanged → STATUS_ERROR), και δεν θέλουμε να κολλήσουν οι ενημερώσεις του skin/βοηθού.

Άνοιγμα παιχνιδιού SorbettoGames: RunScript(plugin.program.sorbetto.games,game=<id>) (από 1.0.12).
"""
import json
import os
import re
import shutil
from urllib.parse import quote

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import menu

# Ίδιο id με το παλιό «Retro Gaming»: κρατά τη ρύθμιση retro_on (εμφάνιση από «Ενότητες στην
# αρχική», κρυμμένο από προεπιλογή) και τα κρυμμένα κουμπιά κάθε χρήστη όπως είναι.
MENU_ID = 'retrogaming'
LIST_URL = 'plugin://script.sorbetto.helper/?action=games'
WIDGET_URL = 'plugin://script.sorbetto.helper/?action=gameswidget'
GAME_URL = 'plugin://script.sorbetto.helper/?action=game&id=%s'
SETTINGS_URL = 'plugin://script.sorbetto.helper/?action=sgsettings'
GAMES_DIR = os.path.join(menu.PROFILE, 'games')

SG_ID = 'plugin.program.sorbetto.games'
SG_REPO = 'repository.sorbetto.games'
SG_PREFIX = 'sg.'          # id στο μενού: 'sg.<id παιχνιδιού>' · σκέτο 'sg.' = όλη η λίστα του SorbettoGames
SG_GAME_ID = re.compile(r'^[a-z0-9-]+$')
# Ο κατάλογος και online (ίδιος με του πρόσθετου): για να δείχνει το widget όλα τα παιχνίδια
# ακόμα κι αν το SorbettoGames δεν έχει εγκατασταθεί. Κρατιέται τοπικά, ανανεώνεται στην εκκίνηση.
SG_CATALOG_URL = 'https://hermesgr.github.io/SorbettoGames/catalog.json'
SG_CACHE = os.path.join(menu.PROFILE, 'sorbettogames-catalog.json')
UA = 'Mozilla/5.0 (Linux; Android 11) Sorbetto-Helper/1.3'

# Κουμπί της αρχικής, πάνω από τα «Αγαπημένα» (αν δεν υπάρχει ήδη στο μενού του WordPress).
MENU_ITEM = {
    'id': MENU_ID,
    'label': 'ΠΑΙΧΝΙΔΙΑ',
    'label_en': 'GAMES',
    'icon': 'play',
    'action': 'ActivateWindow(Programs,"%s",return)' % LIST_URL,
    'widget': WIDGET_URL,
    'widget_label': 'Παιχνίδια με ένα κλικ',
    'widget_label_en': 'One-click games',
    'description': 'Κλασικά παιχνίδια: Super Nintendo, Mega Drive, NES, Amiga, Arcade, PlayStation και Rick Dangerous.',
    'description_en': 'Classic games: Super Nintendo, Mega Drive, NES, Amiga, Arcade, PlayStation and Rick Dangerous.',
    'show': '',
}

RICK = {'id': 'xrick', 'core': 'game.libretro.xrick', 'label': 'Rick Dangerous',
        'el': 'Το κλασικό platform του 1989: ο Rick ξεφεύγει από παγίδες σε ναούς και κάστρα.',
        'en': 'The 1989 platform classic: Rick dodges traps in temples and castles.'}
# Στη λίστα και στο widget το Rick Dangerous μπαίνει κάτω από αυτό το παιχνίδι του SorbettoGames.
RICK_AFTER = 'donkey-kong-country'

# Αφαιρέθηκαν: 1.3.22 The Powder Toy, Beneath a Steel Sky, Flight of the Amazon Queen ·
# 1.3.30 όλο το παλιό «Retro Gaming» εκτός από το Rick Dangerous.
# Σε όσα box υπάρχουν, σβήνονται μία φορά (cleanup_removed, από το service).
REMOVED_CORES = ('game.libretro.thepowdertoy', 'game.libretro.scummvm',
                 'game.libretro.prboom', 'game.libretro.ecwolf', 'game.libretro.nx',
                 'game.libretro.mrboom', 'game.libretro.dinothawr', 'game.libretro.2048',
                 'game.libretro.gong')
REMOVED_DATA = ('bass', 'fotaq', 'freedoom', 'cavestory', 'wolf3d')


def cleanup_removed():
    """Σβήνει τα πρόσθετα και τα αρχεία των παιχνιδιών που αφαιρέθηκαν. Επιστρέφει True αν
    σβήστηκε πρόσθετο (τότε χρειάζεται UpdateLocalAddons: το Kodi βγάζει από τη βάση του όσα
    δεν υπάρχουν πια στον δίσκο, AddonMgr FindAddons → SyncInstalled)."""
    for key in REMOVED_DATA:
        shutil.rmtree(os.path.join(GAMES_DIR, key), ignore_errors=True)
        shutil.rmtree(os.path.join(GAMES_DIR, key + '.tmp'), ignore_errors=True)
    removed = False
    for core in REMOVED_CORES:
        folder = xbmcvfs.translatePath('special://home/addons/%s' % core)
        if os.path.isdir(folder):
            shutil.rmtree(folder, ignore_errors=True)
            shutil.rmtree(xbmcvfs.translatePath('special://profile/addon_data/%s' % core), ignore_errors=True)
            removed = not os.path.isdir(folder) or removed
            menu.log('παιχνίδια: αφαιρέθηκε το %s' % core)
    return removed

TEXT = {
    'el': {
        'install': 'Γίνεται εγκατάσταση του παιχνιδιού…',
        'nocore': 'Το παιχνίδι δεν είναι ακόμα εγκατεστημένο. Δοκιμάστε ξανά σε λίγο.',
        'title': 'Παιχνίδια',
        'all': 'Όλα τα παιχνίδια',
        'allplot': 'Ολόκληρη η λίστα του Sorbetto Games, με φίλτρο ανά κονσόλα.',
        'setup': 'Πατήστε για εγκατάσταση. Γίνεται μία φορά.',
        'sginstall': 'Εγκατάσταση του Sorbetto Games…',
        'sgfail': 'Δεν ολοκληρώθηκε η εγκατάσταση του Sorbetto Games. Δοκιμάστε ξανά σε λίγο.',
        'settings': 'Ρυθμίσεις',
        'settingsplot': 'Ρυθμίσεις του Sorbetto Games.',
    },
    'en': {
        'install': 'Installing the game…',
        'nocore': 'The game is not installed yet. Please try again shortly.',
        'title': 'Games',
        'all': 'All games',
        'allplot': 'The full Sorbetto Games list, with a console filter.',
        'setup': 'Press to install. This happens once.',
        'sginstall': 'Installing Sorbetto Games…',
        'sgfail': 'Sorbetto Games could not be installed. Please try again shortly.',
        'settings': 'Settings',
        'settingsplot': 'Sorbetto Games settings.',
    },
}


def t(key):
    return TEXT[menu.lang()][key]


def has(addon_id):
    return xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id)


def icon(addon_id):
    res = menu.jsonrpc('Addons.GetAddonDetails', {'addonid': addon_id, 'properties': ['thumbnail', 'fanart']})
    addon = ((res or {}).get('result') or {}).get('addon') or {}
    return addon.get('thumbnail') or 'DefaultAddonGame.png', addon.get('fanart') or ''


# ---------------------------------------------------------------- SorbettoGames

def _read_catalog(path):
    try:
        with open(path, encoding='utf-8') as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return []
    games = data.get('games', []) if isinstance(data, dict) else []
    return [g for g in games if isinstance(g, dict) and SG_GAME_ID.match(str(g.get('id', '')))]


def refresh_sg_catalog(timeout=10):
    """Κατεβάζει τον online κατάλογο στο SG_CACHE. Επιστρέφει True αν γράφτηκε."""
    from urllib.request import Request, urlopen
    try:
        with urlopen(Request(SG_CATALOG_URL, headers={'User-Agent': UA}), timeout=timeout) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        if not isinstance(data, dict) or not isinstance(data.get('games'), list) or not data['games']:
            raise ValueError('κενός ή άκυρος κατάλογος')
        if not os.path.isdir(menu.PROFILE):
            os.makedirs(menu.PROFILE)
        tmp = SG_CACHE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, SG_CACHE)
        return True
    except Exception as exc:
        menu.log('παιχνίδια: ο online κατάλογος δεν κατέβηκε (%s)' % exc, xbmc.LOGWARNING)
        return False


def _sg_catalog():
    """Ο κατάλογος του εγκατεστημένου πρόσθετου· αλλιώς ο online (τοπικό αντίγραφο)."""
    if has(SG_ID):
        games = _read_catalog(xbmcvfs.translatePath('special://home/addons/%s/resources/catalog.json' % SG_ID))
        if games:
            return games
    if not os.path.isfile(SG_CACHE):
        refresh_sg_catalog(timeout=5)
    return _read_catalog(SG_CACHE)


def _sg_platform(game):
    """Η κονσόλα όπως τη βρήκε το SorbettoGames στη λήψη (1.0.11+), αλλιώς του καταλόγου."""
    marker = xbmcvfs.translatePath('special://profile/addon_data/%s/games/%s/sorbetto-platform.txt' % (SG_ID, game['id']))
    try:
        with open(marker, encoding='utf-8') as fh:
            return fh.read().strip() or game.get('platform', '')
    except OSError:
        return game.get('platform', '')


def _sg_thumb(game, sg_icon):
    """Ίδια λογική με το SorbettoGames: δική του αποθηκευμένη εικόνα, αλλιώς εξώφυλλο Libretro,
    και για τα Arcade το εικονίδιο του πρόσθετου."""
    cached = xbmcvfs.translatePath('special://profile/addon_data/%s/artwork/%s.png' % (SG_ID, game['id']))
    if os.path.isfile(cached):
        return cached
    if _sg_platform(game) == 'arcade' or not game.get('art_system') or not game.get('art_title'):
        return sg_icon
    return 'https://thumbnails.libretro.com/%s/Named_Boxarts/%s' % (
        quote(game['art_system'], safe=''), quote(game['art_title'] + '.png', safe=''))


def _sg_line(game):
    """Κονσόλα • έτος • είδος (πεδία του καταλόγου, SorbettoGames 1.0.48+)."""
    return ' • '.join(str(x) for x in (game.get('category', ''), game.get('year', ''), game.get('genre', '')) if x)


def _sg_plot(game):
    lines = [_sg_line(game)]
    if game.get('developer'):
        lines.append(('Δημιουργός: ' if menu.lang() == 'el' else 'Developer: ') + game['developer'])
    if game.get('description'):
        lines += ['', game['description']]
    return '\n'.join(lines)


def entries(with_all=False):
    """Τα παιχνίδια για τη λίστα και το widget: SorbettoGames πρώτα (με τη σειρά του καταλόγου,
    ακόμα κι αν το πρόσθετο δεν έχει εγκατασταθεί), Rick Dangerous αμέσως μετά το RICK_AFTER
    (αν λείπει από τον κατάλογο, στο τέλος).
    Κάθε στοιχείο: id, label, thumb, fanart, plot."""
    out = []
    current = menu.lang()
    catalog = _sg_catalog()
    if catalog:
        sg_icon, sg_fanart = icon(SG_ID)
        if with_all:
            out.append({'id': SG_PREFIX, 'label': t('all'), 'thumb': sg_icon, 'fanart': sg_fanart, 'plot': t('allplot')})
        for game in catalog:
            out.append({'id': SG_PREFIX + game['id'], 'label': game.get('title', game['id']),
                        'thumb': _sg_thumb(game, sg_icon), 'fanart': sg_fanart, 'plot': _sg_plot(game),
                        'label2': _sg_line(game)})
    else:
        # Ούτε πρόσθετο ούτε online κατάλογος (π.χ. χωρίς internet): ένα στοιχείο για εγκατάσταση.
        out.append({'id': SG_PREFIX, 'label': t('title'), 'thumb': 'DefaultAddonGame.png',
                    'fanart': '', 'plot': t('setup')})
    if has(RICK['core']):
        thumb, fanart = icon(RICK['core'])
        rick = {'id': RICK['id'], 'label': RICK['label'], 'thumb': thumb, 'fanart': fanart,
                'plot': RICK[current]}
        after = [i for i, e in enumerate(out) if e['id'] == SG_PREFIX + RICK_AFTER]
        out.insert(after[0] + 1 if after else len(out), rick)
    return out


def _wait_for(addon_id, seconds):
    for _ in range(seconds * 2):
        if has(addon_id):
            return True
        xbmc.sleep(500)
    return has(addon_id)


def ensure_sorbettogames():
    """Εγκαθιστά το SorbettoGames αν λείπει: πρώτα το αποθετήριο, μετά το πρόσθετο.
    Το Kodi ρωτά «Να εγκατασταθεί;» για το καθένα (InstallAddon)."""
    if has(SG_ID):
        return True
    xbmcgui.Dialog().notification('Sorbetto Games', t('sginstall'), xbmcgui.NOTIFICATION_INFO, 3000, False)
    if not has(SG_REPO):
        xbmc.executebuiltin('InstallAddon(%s)' % SG_REPO, True)
        if not _wait_for(SG_REPO, 15):
            # ίσως το Kodi δεν έχει δει ακόμα τη νέα εγγραφή στο Sorbetto Repository
            xbmc.executebuiltin('UpdateAddonRepos', True)
            xbmc.sleep(3000)
            xbmc.executebuiltin('InstallAddon(%s)' % SG_REPO, True)
            if not _wait_for(SG_REPO, 15):
                menu.log('παιχνίδια: δεν εγκαταστάθηκε το %s' % SG_REPO, xbmc.LOGWARNING)
                xbmcgui.Dialog().ok('Sorbetto Games', t('sgfail'))
                return False
        # μόλις μπήκε: να διαβάσει το Kodi τη λίστα του πριν ζητήσουμε το πρόσθετο
        xbmc.executebuiltin('UpdateAddonRepos', True)
        xbmc.sleep(3000)
    xbmc.executebuiltin('InstallAddon(%s)' % SG_ID, True)
    if not _wait_for(SG_ID, 30):
        menu.log('παιχνίδια: δεν εγκαταστάθηκε το %s' % SG_ID, xbmc.LOGWARNING)
        xbmcgui.Dialog().ok('Sorbetto Games', t('sgfail'))
        return False
    return True


def settings_entry():
    """Τελευταίο στοιχείο της λίστας και του widget: οι ρυθμίσεις του SorbettoGames."""
    return {'id': 'sgsettings', 'label': t('settings'), 'thumb': 'DefaultAddonService.png', 'fanart': '',
            'plot': t('settingsplot')}


def settings_path():
    """Για το widget: όπως favourite_path, το κλικ εκτελεί RunPlugin(...?action=sgsettings)."""
    return 'favourites://' + quote('RunPlugin("%s")' % SETTINGS_URL, safe='')


def open_sg_settings():
    if ensure_sorbettogames():
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % SG_ID)


# ---------------------------------------------------------------- widget / άνοιγμα

def favourite_path(game_id):
    """Διαδρομή για το widget: το Kodi εκτελεί την εντολή που είναι μέσα (FavouritesURL.cpp),
    όπως ένα αγαπημένο. Έτσι το κλικ στο widget ανοίγει το παιχνίδι κατευθείαν."""
    cmd = 'RunPlugin("%s")' % (GAME_URL % game_id)
    return 'favourites://' + quote(cmd, safe='')


def _ensure_core(game):
    core = game['core']
    if has(core):
        return True
    # εγκατεστημένο αλλά απενεργοποιημένο;
    res = menu.jsonrpc('Addons.GetAddonDetails', {'addonid': core, 'properties': ['enabled']})
    addon = ((res or {}).get('result') or {}).get('addon')
    if addon and addon.get('enabled') is False:
        menu.jsonrpc('Addons.SetAddonEnabled', {'addonid': core, 'enabled': True})
        xbmc.sleep(500)
        return has(core)
    # δεν υπάρχει: το Kodi ρωτά «Να εγκατασταθεί;» και το κατεβάζει από το επίσημο αποθετήριο
    xbmcgui.Dialog().notification('Sorbetto Games', t('install'), xbmcgui.NOTIFICATION_INFO, 3000, False)
    xbmc.executebuiltin('InstallAddon(%s)' % core, True)
    if _wait_for(core, 10):
        return True
    xbmcgui.Dialog().ok('Sorbetto Games', t('nocore'))
    return False


def play(game_id):
    if game_id.startswith(SG_PREFIX):
        wanted = game_id[len(SG_PREFIX):]
        if wanted and not SG_GAME_ID.match(wanted):
            return
        if not ensure_sorbettogames():
            return
        if wanted:
            xbmc.executebuiltin('RunScript(%s,game=%s)' % (SG_ID, wanted))
        else:
            xbmc.executebuiltin('RunScript(%s)' % SG_ID)
        return
    if game_id != RICK['id'] or not _ensure_core(RICK):
        return
    menu.log('παιχνίδια: %s με %s' % (RICK['label'], RICK['core']))
    xbmc.executebuiltin('RunAddon(%s)' % RICK['core'])
