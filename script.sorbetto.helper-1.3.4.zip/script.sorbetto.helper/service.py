# -*- coding: utf-8 -*-
"""Τρέχει ΜΙΑ φορά σε κάθε εκκίνηση του Kodi και κλείνει.

1. Την πρώτη φορά βάζει το Kodi στα Ελληνικά (προεπιλογή του build).
2. Κατεβάζει το μενού και τα φόντα από το WordPress και τα κρατά τοπικά.
3. Λέει στην αρχική να τα ξαναφορτώσει (αλλάζει ιδιότητες του παραθύρου Home).
4. Ζητά έλεγχο ενημερώσεων για αποθετήρια και πρόσθετα.
5. Μία φορά: υπότιτλοι σειρών και ταινιών από το OpenSubtitles.org.
"""
import xbmc
import xbmcgui

from resources.lib import menu


def first_run_language():
    if menu.ADDON.getSettingBool('lang_init'):
        return
    menu.ADDON.setSettingBool('lang_init', True)
    if menu.lang() != 'el':
        menu.log('πρώτη εκκίνηση: αλλαγή γλώσσας σε Ελληνικά')
        xbmc.executebuiltin('SetGUILanguage(resource.language.el_gr)')


SUBS_ADDON = 'service.subtitles.opensubtitles'


def first_run_subtitles():
    """Μία φορά: προεπιλεγμένη υπηρεσία υποτίτλων για σειρές και ταινίες = OpenSubtitles.org.
    Μετά ο χρήστης μπορεί να την αλλάξει ελεύθερα· δεν την ξαναπειράζουμε."""
    if menu.ADDON.getSettingBool('subs_init'):
        return
    if not xbmc.getCondVisibility('System.HasAddon(%s)' % SUBS_ADDON):
        menu.log('υπότιτλοι: το %s δεν είναι ακόμα εγκατεστημένο, ξανά στην επόμενη εκκίνηση' % SUBS_ADDON)
        return
    ok = True
    for setting in ('subtitles.tv', 'subtitles.movie'):
        res = menu.jsonrpc('Settings.SetSettingValue', {'setting': setting, 'value': SUBS_ADDON})
        if res.get('result') is not True:
            ok = False
            menu.log('υπότιτλοι: δεν άλλαξε το %s (%s)' % (setting, res))
    if ok:
        menu.ADDON.setSettingBool('subs_init', True)
        menu.log('υπότιτλοι: σειρές και ταινίες από OpenSubtitles.org')


def run():
    home = xbmcgui.Window(10000)
    first_run_language()
    first_run_subtitles()
    # Η «Επεξεργασία μενού» φαίνεται μόνο στο Kodi που έχει κλειδί διαχειριστή.
    if menu.ADDON.getSettingString('admin_key').strip():
        home.setProperty('sorbetto.admin', 'true')
    else:
        home.clearProperty('sorbetto.admin')

    data = menu.fetch(menu.ADDON.getSettingString('menu_url'))
    if data:
        menu.save(data)
        menu.log('νέο μενού, έκδοση %s, %d κουμπιά' % (data['version'], len(data['items'])))
    else:
        data = menu.load()
        menu.log('χρησιμοποιείται το αποθηκευμένο μενού, έκδοση %s' % data['version'])
    home.setProperty(menu.PROP_VERSION, str(data['version']))

    bgs = menu.fetch(menu.ADDON.getSettingString('bg_url'), cleaner=menu.clean_backgrounds)
    if bgs is not None:
        menu.save(bgs, menu.BG_CACHE_FILE)
        menu.log('φόντα: %d, έκδοση %s' % (len(bgs['items']), bgs['version']))
    else:
        bgs = menu.load_backgrounds()
    home.setProperty(menu.PROP_BG_VERSION, str(bgs['version']))

    if menu.ADDON.getSettingBool('check_updates'):
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmc.executebuiltin('UpdateLocalAddons')


if __name__ == '__main__':
    run()
