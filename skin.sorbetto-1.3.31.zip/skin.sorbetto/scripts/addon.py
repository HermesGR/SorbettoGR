# -*- coding: utf-8 -*-
"""Sorbetto: πρόσθετο στη σειρά «Πρόσθετα» της αρχικής που ΔΕΝ είναι προεγκατεστημένο.

    RunScript(special://skin/scripts/addon.py,myiptv)

Με το πάτημα:
- αν είναι εγκατεστημένο: ανοίγει·
- αν δεν είναι: το Kodi ρωτά «Να εγκατασταθεί;» (InstallAddon, InstallModal με ερώτηση,
  AddonBuiltins.cpp), το εγκαθιστά με το «Ναι» και μετά ανοίγει.

Το id δεν το ξέρουμε από πριν (το αποθετήριο GKoBu δεν διαβάζεται από εμάς): το βρίσκουμε
στο κουτί από το ΟΝΟΜΑ, ρωτώντας το Kodi για όλα τα πρόσθετα, εγκατεστημένα και διαθέσιμα στα
αποθετήριά του (JSON-RPC Addons.GetAddons, installed=all → GetInstallableAddons). Το id που
βρέθηκε κρατιέται στο Skin.String(sorbetto_<κλειδί>_id) για το εικονίδιο της σειράς.
"""
import json
import re
import sys

import xbmc
import xbmcgui

TARGETS = {
    # κλειδί: (όνομα όπως φαίνεται στο Kodi, κανονικοποιημένο: πεζά χωρίς κενά/σύμβολα)
    'myiptv': ('MyIPTV', 'myiptv'),
}
TAG_RE = re.compile(r'\[/?[A-Za-z]+[^\]]*\]')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Sorbetto Addon] %s' % msg, level)


def text(el, en):
    return el if xbmc.getLanguage(xbmc.ISO_639_1) == 'el' else en


def rpc(method, params):
    res = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method,
                                                     'params': params})))
    if 'error' in res:
        raise RuntimeError(res['error'].get('message', 'JSON-RPC'))
    return res.get('result', {})


def norm(name):
    return re.sub(r'[^a-z0-9]', '', TAG_RE.sub('', name or '').lower())


def find(key):
    """Το πρόσθετο με αυτό το όνομα: (id, εγκατεστημένο, ενεργό) ή None. Προτιμά το εγκατεστημένο."""
    try:
        addons = rpc('Addons.GetAddons', {'installed': 'all', 'properties': ['name', 'installed', 'enabled']})
        addons = addons.get('addons') or []
    except Exception as exc:
        log('λίστα πρόσθετων: %s' % exc, xbmc.LOGWARNING)
        return None
    # μόνο ακριβές όνομα: αλλιώς ένα «MyIPTV Plus» θα έπιανε τη θέση του
    hits = [a for a in addons if norm(a.get('name')) == key]
    if not hits:
        return None
    hits.sort(key=lambda a: (not a.get('installed'), not a.get('enabled'), a.get('addonid', '')))
    best = hits[0]
    log('βρέθηκε %s (%s), εγκατεστημένο: %s' % (best.get('addonid'), TAG_RE.sub('', best.get('name', '')),
                                                 best.get('installed')))
    return best['addonid'], bool(best.get('installed')), bool(best.get('enabled'))


def is_installed(addon_id):
    try:
        return bool(rpc('Addons.GetAddonDetails', {'addonid': addon_id, 'properties': ['enabled']}).get('addon'))
    except Exception:
        return False


def run(key):
    if key not in TARGETS:
        log('άγνωστο: %s' % key, xbmc.LOGWARNING)
        return
    label, wanted = TARGETS[key]
    found = find(wanted)
    if found is None:
        xbmcgui.Dialog().notification(
            'Sorbetto', text('Το %s δεν βρέθηκε στα αποθετήρια αυτού του κουτιού.' % label,
                             '%s was not found in this device\'s repositories.' % label),
            xbmcgui.NOTIFICATION_WARNING, 5000)
        log('το %s δεν υπάρχει σε κανένα αποθετήριο του κουτιού' % label, xbmc.LOGWARNING)
        return
    addon_id, installed, enabled = found
    if not installed:
        xbmc.executebuiltin('InstallAddon(%s)' % addon_id, True)  # ρωτά τον χρήστη πρώτα
        if not is_installed(addon_id):
            log('%s: δεν εγκαταστάθηκε (ο χρήστης είπε όχι ή απέτυχε)' % addon_id)
            return
    elif not enabled:
        try:
            rpc('Addons.SetAddonEnabled', {'addonid': addon_id, 'enabled': True})
        except Exception as exc:
            log('%s: δεν ενεργοποιήθηκε: %s' % (addon_id, exc), xbmc.LOGWARNING)
            return
    xbmc.executebuiltin('Skin.SetString(sorbetto_%s_id,%s)' % (key, addon_id))
    xbmc.executebuiltin('RunAddon(%s)' % addon_id)


if __name__ == '__main__':
    run(sys.argv[1] if len(sys.argv) > 1 else '')
