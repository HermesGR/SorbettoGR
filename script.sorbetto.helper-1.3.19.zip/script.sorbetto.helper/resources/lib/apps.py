# -*- coding: utf-8 -*-
"""Εφαρμογές Android (Netflix, Magenta TV, Nova) μέσα στην ενότητα «Πρόσθετα».

Φαίνονται ΜΟΝΟ όσες είναι εγκατεστημένες στο box. Τις βρίσκουμε από τη λίστα εφαρμογών που
δίνει το ίδιο το Kodi στο Android (androidapp://sources/apps/, AndroidAppDirectory.cpp), με
βάση το όνομα της εφαρμογής, ώστε να πιάνεται και η έκδοση για Android TV και η έκδοση για
κινητό χωρίς να ξέρουμε το ακριβές πακέτο. Ανοίγουν με StartAndroidActivity, έξω από το Kodi·
με το «Πίσω» από την αρχική τους οθόνη το Android γυρνά στο Kodi.
"""
import re

import xbmc

from resources.lib import menu

APP_DIR = 'androidapp://sources/apps/'

# (κλειδί, κανονική έκφραση για το όνομα της εφαρμογής), με τη σειρά που εμφανίζονται
APPS = (
    ('netflix', re.compile(r'netflix', re.I)),
    ('magenta', re.compile(r'magenta', re.I)),
    ('nova', re.compile(r'\bnova(flix|\s*go)?\b', re.I)),
)
# ονόματα που μοιάζουν αλλά δεν είναι οι εφαρμογές που θέλουμε
EXCLUDE = re.compile(r'launcher|keyboard|wallpaper|widget', re.I)


def installed():
    """Λίστα [{'key','label','pkg','icon'}] με τις εγκατεστημένες εφαρμογές, με τη σειρά του APPS."""
    if not xbmc.getCondVisibility('System.Platform.Android'):
        return []
    res = menu.jsonrpc('Files.GetDirectory', {'directory': APP_DIR, 'media': 'files'})
    files = ((res or {}).get('result') or {}).get('files') or []
    found = []
    for key, pattern in APPS:
        for f in files:
            label = (f.get('label') or '').strip()
            path = f.get('file') or ''
            pkg = path.rstrip('/').rsplit('/', 1)[-1]
            if not label or not pkg or EXCLUDE.search(label) or not pattern.search(label):
                continue
            found.append({'key': key, 'label': label, 'pkg': pkg,
                          'icon': APP_DIR + pkg + '.png'})
            break  # μία ανά εφαρμογή
    return found


def start(pkg):
    if re.match(r'^[A-Za-z0-9_.]+$', pkg or ''):
        xbmc.executebuiltin('StartAndroidActivity(%s)' % pkg)


def video_addons():
    """Τα πρόσθετα βίντεο (ό,τι έδειχνε πριν το widget addons://user/xbmc.addon.video)."""
    res = menu.jsonrpc('Addons.GetAddons', {'type': 'xbmc.addon.video', 'enabled': True,
                                            'properties': ['name', 'thumbnail']})
    addons = ((res or {}).get('result') or {}).get('addons') or []
    out = [a for a in addons if a.get('addonid') and a.get('addonid') != 'script.sorbetto.helper']
    return sorted(out, key=lambda a: (a.get('name') or a['addonid']).lower())
