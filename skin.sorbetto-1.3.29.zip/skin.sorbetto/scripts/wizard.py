# -*- coding: utf-8 -*-
"""Sorbetto: κουμπιά του GrecoTM Wizard μέσα από τις Ρυθμίσεις Sorbetto.

    RunScript(special://skin/scripts/wizard.py,dnsleak)      «DNS Leak Test»      (Misc Maintenance)
    RunScript(special://skin/scripts/wizard.py,forceupdate)  «Force Update Addons» (Addon Tools)

Δεν έχουμε τον κώδικα του wizard (plugin.program.G.K.N.Wizard), οπότε τον διαβάζουμε από
το ίδιο το κουτί: ψάχνουμε στα .py του τη γραμμή του μενού με το όνομα του κουμπιού, π.χ.
    directory.add_file('DNS Leak Test', {'mode': 'dnsleak'}, ...)
παίρνουμε τις παραμέτρους της και καλούμε το wizard με την ίδια διεύθυνση που φτιάχνει κι
αυτό για το κουμπί του (plugin://<id>/?mode=...&..., όπως το _add_menu_item του OpenWizard,
πάνω στο οποίο είναι χτισμένο). Δηλαδή πατάμε το δικό του κουμπί.

Αν δεν βρεθεί (άλλη έκδοση, κρυπτογραφημένος κώδικας): το Force Update πάει με τη γνωστή
εντολή του OpenWizard (mode=forceupdate&action=auto), και το DNS Leak Test ανοίγει το wizard
στο «Misc Maintenance» για να το πατήσει ο χρήστης. Ό,τι βρέθηκε γράφεται στο kodi.log
([Sorbetto Wizard]).

Χωρίς κείμενα του skin (xbmc.getLocalizedString δεν δίνει κείμενα skin σε script): τα λίγα
μηνύματα είναι εδώ, σε Ελληνικά/Αγγλικά.
"""
import ast
import os
import re
import sys
from urllib.parse import quote_plus

import xbmc
import xbmcgui
import xbmcvfs

WIZARD = 'plugin.program.G.K.N.Wizard'
SETTINGS_DIALOG = 1153

TARGETS = {
    'dnsleak': {
        'label': re.compile(r'dns\W*leak', re.I),
        'fallback': None,                                    # ανοίγει το Misc Maintenance
        'menu': re.compile(r'misc\W*maint', re.I),
    },
    'forceupdate': {
        'label': re.compile(r'force\W*update\W*(all\W*)?add-?ons?', re.I),
        'fallback': ({'mode': 'forceupdate', 'action': 'auto'}, False),
        'menu': re.compile(r'addon\W*tools', re.I),
    },
}

# add_file('Ετικέτα', {...}  ή  add_dir("Ετικέτα", {...}
# η ετικέτα μέσα σε μία γραμμή (αλλιώς μια ετικέτα με .format(...) «τρέχει» ως το επόμενο κουμπί)
ITEM_RE = re.compile(r'add_(file|dir)\(\s*(?P<q>[\'"])(?P<label>[^\'"\n]*)(?P=q)\s*,\s*(?P<params>\{[^{}]*\})')
MODE_RE = re.compile(r'[\'"]mode[\'"]\s*:\s*[\'"]([^\'"]+)[\'"]')
PAIR_RE = re.compile(r'[\'"](\w+)[\'"]\s*:\s*[\'"]([^\'"]*)[\'"]')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Sorbetto Wizard] %s' % msg, level)


def text(el, en):
    return el if xbmc.getLanguage(xbmc.ISO_639_1) == 'el' else en


def notify(el, en):
    xbmcgui.Dialog().notification('Sorbetto', text(el, en), xbmcgui.NOTIFICATION_INFO, 4000)


def wizard_dir():
    return xbmcvfs.translatePath('special://home/addons/%s/' % WIZARD)


def _params(raw):
    try:
        value = ast.literal_eval(raw)
        if isinstance(value, dict) and value.get('mode'):
            return {str(k): str(v) for k, v in value.items()}
    except Exception:
        pass
    # οι τιμές δεν είναι όλες σταθερές (π.χ. CONFIG.…): κρατάμε όσες είναι
    if MODE_RE.search(raw):
        return dict(PAIR_RE.findall(raw))
    return None


def find(label_re):
    """(παράμετροι, είναι_φάκελος) του κουμπιού του wizard με αυτό το όνομα, ή None."""
    root = wizard_dir()
    for base, _dirs, files in os.walk(root):
        for name in sorted(files):
            if not name.endswith('.py'):
                continue
            path = os.path.join(base, name)
            try:
                with open(path, encoding='utf-8', errors='replace') as fh:
                    code = fh.read()
            except OSError:
                continue
            for m in ITEM_RE.finditer(code):
                label = re.sub(r'\[/?[A-Z]+[^\]]*\]', '', m.group('label'))  # χωρίς [COLOR]/[B]
                if not label_re.search(label):
                    continue
                params = _params(m.group('params'))
                if params:
                    log('βρέθηκε «%s» στο %s: %s' % (label, os.path.relpath(path, root), params))
                    return params, m.group(1) == 'dir'
    return None


def url(params):
    u = 'plugin://%s/?mode=%s' % (WIZARD, quote_plus(params.get('mode', '')))
    for key, value in params.items():
        if key != 'mode':
            u += '&%s=%s' % (key, quote_plus(value))
    return u


def open_folder(target):
    xbmc.executebuiltin('Dialog.Close(%d,true)' % SETTINGS_DIALOG)  # αλλιώς το Kodi δεν ανοίγει παράθυρο
    xbmc.executebuiltin('ActivateWindow(10001,"%s",return)' % target)


def run(action):
    target = TARGETS.get(action)
    if not target:
        log('άγνωστη εντολή: %s' % action, xbmc.LOGWARNING)
        return
    # όχι System.HasAddon: το Kodi κάνει πεζά όλο τον όρο και το id του wizard έχει κεφαλαία
    if not os.path.isfile(os.path.join(wizard_dir(), 'addon.xml')):
        notify('Το GrecoTM Wizard δεν είναι εγκατεστημένο.', 'GrecoTM Wizard is not installed.')
        log('το %s λείπει' % WIZARD, xbmc.LOGWARNING)
        return
    found = find(target['label'])
    if found is None and target['fallback']:
        found = target['fallback']
        log('δεν βρέθηκε το κουμπί στον κώδικα, εντολή του OpenWizard: %s' % found[0])
    if found is not None:
        params, is_dir = found
        if is_dir:
            open_folder(url(params))
        else:
            xbmc.executebuiltin('RunPlugin(%s)' % url(params))
        return
    # δεν βρέθηκε: ανοίγει η ενότητα του wizard για να το πατήσει ο χρήστης
    menu = find(target['menu'])
    log('δεν βρέθηκε το κουμπί «%s», ανοίγει %s' % (action, menu[0] if menu else 'η αρχή του wizard'))
    open_folder(url(menu[0]) if menu else 'plugin://%s/' % WIZARD)


if __name__ == '__main__':
    run(sys.argv[1] if len(sys.argv) > 1 else '')
