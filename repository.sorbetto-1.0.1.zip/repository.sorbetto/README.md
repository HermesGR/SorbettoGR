# Sorbetto Repository (repository.sorbetto)

Αποθετήριο Kodi στο GitHub Pages: https://hermesgr.github.io/SorbettoGR/
Περιέχει: skin.sorbetto, script.sorbetto.helper.

## Εκδόσεις

### 1.0.1 — 15/10/2026
- Νέα μικρή υπηρεσία (`service.py`): αν το `skin.sorbetto` ή το `script.sorbetto.helper` έχουν κενή «προέλευση» στη βάση πρόσθετων του Kodi (μπήκαν από zip ή μέσα από build), γράφει `repository.sorbetto` και ζητά αμέσως έλεγχο ενημερώσεων. Με κενή προέλευση το Kodi ψάχνει ενημερώσεις μόνο στα επίσημα αποθετήρια (AddonRepos.cpp).
- Το ίδιο το αποθετήριο ενημερώνεται αυτόματα παντού (έχει σωστή προέλευση) και η υπηρεσία του ξεκινά αμέσως μετά την ενημέρωση (Service.cpp, ReInstalled), άρα η διόρθωση φτάνει και στα box που έχουν ήδη το build.

### 1.0.0 — 14/10/2026
- Πρώτη έκδοση. Δείχνει στο https://hermesgr.github.io/SorbettoGR/ (addons.xml, addons.xml.md5, zip ανά πρόσθετο στο <id>/<id>-<έκδοση>.zip).
