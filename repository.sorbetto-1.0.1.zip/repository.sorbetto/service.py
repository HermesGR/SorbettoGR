# -*- coding: utf-8 -*-
"""Sorbetto Repository: «δένει» το skin και τον βοηθό με αυτό το αποθετήριο.

Το Kodi γράφει για κάθε πρόσθετο από πού εγκαταστάθηκε (installed.origin στο Addons*.db).
Όσα μπήκαν από zip ή μέσα από build έχουν κενή προέλευση, και τότε το Kodi ψάχνει ενημερώσεις
ΜΟΝΟ στα επίσημα αποθετήρια (AddonRepos.cpp), οπότε δεν βλέπει ποτέ το Sorbetto Repository.
Εδώ γράφουμε τη σωστή προέλευση και ζητάμε έλεγχο. Αγγίζουμε μόνο τα δύο δικά μας πρόσθετα
και μόνο όταν η προέλευση είναι κενή. Τρέχει μία φορά και κλείνει.
"""
import glob
import os
import sqlite3

import xbmc
import xbmcvfs

REPO_ID = 'repository.sorbetto'
OWN_ADDONS = ('skin.sorbetto', 'script.sorbetto.helper')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Sorbetto Repository] %s' % msg, level)


def newest_db():
    def number(path):
        digits = ''.join(ch for ch in os.path.basename(path) if ch.isdigit())
        return int(digits) if digits else -1
    dbs = sorted(glob.glob(os.path.join(xbmcvfs.translatePath('special://database/'), 'Addons*.db')), key=number)
    return dbs[-1] if dbs else None


def fix_origin():
    path = newest_db()
    if not path:
        return 0
    try:
        con = sqlite3.connect(path, timeout=10)
        try:
            cur = con.execute(
                "UPDATE installed SET origin=? WHERE addonID IN (?, ?) AND (origin IS NULL OR origin='')",
                (REPO_ID,) + OWN_ADDONS)
            con.commit()
            return cur.rowcount
        finally:
            con.close()
    except sqlite3.Error as exc:
        log('δεν διορθώθηκε η προέλευση: %s' % exc, xbmc.LOGWARNING)
        return 0


def run():
    changed = fix_origin()
    if changed:
        log('%d πρόσθετα δείχνουν πλέον στο %s, έλεγχος ενημερώσεων' % (changed, REPO_ID))
        # UpdateLocalAddons ξαναδιαβάζει την προέλευση από τη βάση (AddonDatabase::GetInstallData)
        xbmc.executebuiltin('UpdateLocalAddons', True)
        xbmc.executebuiltin('UpdateAddonRepos')


if __name__ == '__main__':
    run()
