# -*- coding: utf-8 -*-
"""Τρέχει ΜΙΑ φορά σε κάθε εκκίνηση του Kodi και κλείνει.

1. Την πρώτη φορά βάζει το Kodi στα Ελληνικά (προεπιλογή του build).
2. Κατεβάζει το μενού και τα φόντα από το WordPress και τα κρατά τοπικά.
3. Λέει στην αρχική να τα ξαναφορτώσει (αλλάζει ιδιότητες του παραθύρου Home).
4. Ζητά έλεγχο ενημερώσεων για αποθετήρια και πρόσθετα.
5. Μία φορά: υπότιτλοι σειρών και ταινιών από το OpenSubtitles.org.
6. Διορθώνει την «προέλευση» του skin και του βοηθού ώστε να ενημερώνονται από το Sorbetto Repository.
"""
import glob
import os
import sqlite3

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import admin, menu


def first_run_language():
    if menu.ADDON.getSettingBool('lang_init'):
        return
    menu.ADDON.setSettingBool('lang_init', True)
    if menu.lang() != 'el':
        menu.log('πρώτη εκκίνηση: αλλαγή γλώσσας σε Ελληνικά')
        xbmc.executebuiltin('SetGUILanguage(resource.language.el_gr)')


SUBS_ADDON = 'service.subtitles.opensubtitles'
REPO_ID = 'repository.sorbetto'
OWN_ADDONS = ('skin.sorbetto', 'script.sorbetto.helper')


def fix_origin():
    """Αν το skin ή ο βοηθός μπήκαν από zip (π.χ. μέσα από το build), το Kodi τους έχει κενή
    «προέλευση» και τότε ψάχνει ενημερώσεις ΜΟΝΟ στα επίσημα αποθετήρια (AddonRepos.cpp),
    οπότε δεν βλέπει ποτέ το Sorbetto Repository. Εδώ γράφουμε τη σωστή προέλευση στη βάση
    πρόσθετων του Kodi. Αγγίζουμε μόνο τα δύο δικά μας και μόνο όταν η προέλευση είναι κενή.
    Επιστρέφει True αν άλλαξε κάτι (τότε χρειάζεται UpdateLocalAddons για να το ξαναδιαβάσει)."""
    if not xbmc.getCondVisibility('System.HasAddon(%s)' % REPO_ID):
        return False
    folder = xbmcvfs.translatePath('special://database/')

    def number(path):
        digits = ''.join(ch for ch in os.path.basename(path) if ch.isdigit())
        return int(digits) if digits else -1

    dbs = sorted(glob.glob(os.path.join(folder, 'Addons*.db')), key=number)
    if not dbs:
        return False
    try:
        con = sqlite3.connect(dbs[-1], timeout=10)
        try:
            cur = con.execute(
                "UPDATE installed SET origin=? WHERE addonID IN (?, ?) AND (origin IS NULL OR origin='')",
                (REPO_ID,) + OWN_ADDONS)
            con.commit()
            changed = cur.rowcount
        finally:
            con.close()
    except sqlite3.Error as exc:
        menu.log('προέλευση: δεν διορθώθηκε (%s)' % exc, xbmc.LOGWARNING)
        return False
    if changed:
        menu.log('προέλευση: %d πρόσθετα δείχνουν πλέον στο %s' % (changed, REPO_ID))
    return changed > 0


def first_run_subtitles():
    """Μία φορά: προεπιλεγμένη υπηρεσία υποτίτλων για σειρές και ταινίες = OpenSubtitles.org.
    Μετά ο χρήστης μπορεί να την αλλάξει ελεύθερα· δεν την ξαναπειράζουμε."""
    if menu.ADDON.getSettingBool('subs_init'):
        return
    if not xbmc.getCondVisibility('System.HasAddon(%s)' % SUBS_ADDON):
        menu.log('υπότιτλοι: το %s δεν είναι ακόμα εγκατεστημένο, ξανά στην επόμενη εκκίνηση' % SUBS_ADDON)
        return
    ok = True
    for setting in ('subtitles.tv', 'subtitles.movie'):
        res = menu.jsonrpc('Settings.SetSettingValue', {'setting': setting, 'value': SUBS_ADDON})
        if res.get('result') is not True:
            ok = False
            menu.log('υπότιτλοι: δεν άλλαξε το %s (%s)' % (setting, res))
    if ok:
        menu.ADDON.setSettingBool('subs_init', True)
        menu.log('υπότιτλοι: σειρές και ταινίες από OpenSubtitles.org')


def run():
    home = xbmcgui.Window(10000)
    first_run_language()
    first_run_subtitles()
    # Η «Επεξεργασία μενού» φαίνεται μόνο στο Kodi που έχει κλειδί διαχειριστή.
    if admin.guard():
        home.setProperty('sorbetto.admin', 'true')
    else:
        home.clearProperty('sorbetto.admin')

    data = menu.fetch(menu.ADDON.getSettingString('menu_url'))
    if data:
        menu.save(data)
        menu.log('νέο μενού, έκδοση %s, %d κουμπιά' % (data['version'], len(data['items'])))
    else:
        data = menu.load()
        menu.log('χρησιμοποιείται το αποθηκευμένο μενού, έκδοση %s' % data['version'])
    home.setProperty(menu.PROP_VERSION, str(data['version']))

    bgs = menu.fetch(menu.ADDON.getSettingString('bg_url'), cleaner=menu.clean_backgrounds)
    if bgs is not None:
        menu.save(bgs, menu.BG_CACHE_FILE)
        menu.log('φόντα: %d, έκδοση %s' % (len(bgs['items']), bgs['version']))
    else:
        bgs = menu.load_backgrounds()
    home.setProperty(menu.PROP_BG_VERSION, str(bgs['version']))

    if menu.ADDON.getSettingBool('check_updates'):
        # πρώτα η προέλευση και το UpdateLocalAddons (ξαναδιαβάζει την προέλευση από τη βάση),
        # μετά ο έλεγχος αποθετηρίων, ώστε η ενημέρωση να βρεθεί στην ίδια εκκίνηση
        if fix_origin():
            xbmc.executebuiltin('UpdateLocalAddons', True)
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmc.executebuiltin('UpdateLocalAddons')


if __name__ == '__main__':
    run()
