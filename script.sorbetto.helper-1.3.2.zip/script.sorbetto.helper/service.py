# -*- coding: utf-8 -*-
"""Τρέχει ΜΙΑ φορά σε κάθε εκκίνηση του Kodi και κλείνει.

1. Την πρώτη φορά βάζει το Kodi στα Ελληνικά (προεπιλογή του build).
2. Κατεβάζει το μενού και τα φόντα από το WordPress και τα κρατά τοπικά.
3. Λέει στην αρχική να τα ξαναφορτώσει (αλλάζει ιδιότητες του παραθύρου Home).
4. Ζητά έλεγχο ενημερώσεων για αποθετήρια και πρόσθετα.
"""
import xbmc
import xbmcgui

from resources.lib import menu


def first_run_language():
    if menu.ADDON.getSettingBool('lang_init'):
        return
    menu.ADDON.setSettingBool('lang_init', True)
    if menu.lang() != 'el':
        menu.log('πρώτη εκκίνηση: αλλαγή γλώσσας σε Ελληνικά')
        xbmc.executebuiltin('SetGUILanguage(resource.language.el_gr)')


def run():
    home = xbmcgui.Window(10000)
    first_run_language()
    # Η «Επεξεργασία μενού» φαίνεται μόνο στο Kodi που έχει κλειδί διαχειριστή.
    if menu.ADDON.getSettingString('admin_key').strip():
        home.setProperty('sorbetto.admin', 'true')
    else:
        home.clearProperty('sorbetto.admin')

    data = menu.fetch(menu.ADDON.getSettingString('menu_url'))
    if data:
        menu.save(data)
        menu.log('νέο μενού, έκδοση %s, %d κουμπιά' % (data['version'], len(data['items'])))
    else:
        data = menu.load()
        menu.log('χρησιμοποιείται το αποθηκευμένο μενού, έκδοση %s' % data['version'])
    home.setProperty(menu.PROP_VERSION, str(data['version']))

    bgs = menu.fetch(menu.ADDON.getSettingString('bg_url'), cleaner=menu.clean_backgrounds)
    if bgs is not None:
        menu.save(bgs, menu.BG_CACHE_FILE)
        menu.log('φόντα: %d, έκδοση %s' % (len(bgs['items']), bgs['version']))
    else:
        bgs = menu.load_backgrounds()
    home.setProperty(menu.PROP_BG_VERSION, str(bgs['version']))

    if menu.ADDON.getSettingBool('check_updates'):
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmc.executebuiltin('UpdateLocalAddons')


if __name__ == '__main__':
    run()
