# -*- coding: utf-8 -*-
"""Δίνει στο skin λίστες και εκτελεί μικρές εντολές.

Λίστες (το skin τις καλεί ως περιεχόμενο):
    ?action=menu      κουμπιά του μενού, στη γλώσσα του Kodi
    ?action=bgcats    κατηγορίες φόντων (πρώτη: «Όλα»)
    ?action=bgs&cat=N φόντα της κατηγορίας με αριθμό N (κενό = όλα· πρώτο: «Χωρίς φόντο»)
Εντολές (το skin τις καλεί με RunPlugin):
    ?action=theme&name=<θέμα>   αλλαγή χρωμάτων
    ?action=zoom&v=<αριθμός>    μέγεθος γραμμάτων (μεγέθυνση του skin)
    ?action=zoomnext            Κανονικό -> Μεγάλο -> Πολύ μεγάλο -> Κανονικό
    ?action=langtoggle          Ελληνικά <-> English
    ?action=editor              επεξεργασία μενού (μόνο με κλειδί διαχειριστή)
"""
import re
import sys
from urllib.parse import parse_qsl

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import menu

NOOP = 'plugin://script.sorbetto.helper/?action=noop'
ZOOM_ALLOWED = (0, 6, 12)


def add(handle, label, props, art=None):
    li = xbmcgui.ListItem(label=label, offscreen=True)
    li.setProperties(props)
    if art:
        li.setArt(art)
    xbmcplugin.addDirectoryItem(handle, NOOP, li, False)


def list_menu(handle):
    current = menu.lang()
    for item in menu.load()['items']:
        if item['show'] and item['show'] != current:
            continue
        add(handle, menu.localized(item, 'label', current), {
            'id': item['id'],
            'action': item['action'],
            'icon': item['icon'],
            'widget': item['widget'],
            'widget_label': menu.localized(item, 'widget_label', current),
            'description': menu.localized(item, 'description', current),
        })
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_categories(handle):
    current = menu.lang()
    data = menu.load_backgrounds()
    add(handle, 'Όλα' if current == 'el' else 'All', {'cat': ''})
    for i, c in enumerate(data['categories'], 1):
        add(handle, c['el'] if current == 'el' else c['en'], {'cat': str(i)})
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_backgrounds(handle, cat):
    current = menu.lang()
    data = menu.load_backgrounds()
    chosen = xbmc.getInfoLabel('Skin.String(sorbetto_bg)')
    name = ''
    if cat.isdigit() and 0 < int(cat) <= len(data['categories']):
        name = data['categories'][int(cat) - 1]['el']
    add(handle, 'Χωρίς φόντο' if current == 'el' else 'No background',
        {'url': '', 'none': 'true', 'cur': 'true' if not chosen else ''})
    for bg in data['items']:
        if name and bg['cat'] != name:
            continue
        label = bg['cat'] if current == 'el' else (bg['cat_en'] or bg['cat'])
        add(handle, label, {'url': bg['url'], 'cur': 'true' if bg['url'] == chosen else ''},
            {'thumb': bg['thumb'], 'icon': bg['thumb']})
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def set_theme(name):
    if name != 'SKINDEFAULT' and not re.match(r'^[a-z0-9_]{1,40}$', name):
        return
    menu.jsonrpc('Settings.SetSettingValue', {'setting': 'lookandfeel.skincolors', 'value': name})


def set_zoom(value):
    try:
        value = int(value)
    except (TypeError, ValueError):
        return
    if value in ZOOM_ALLOWED:
        menu.jsonrpc('Settings.SetSettingValue', {'setting': 'lookandfeel.skinzoom', 'value': value})


def zoom_next():
    res = menu.jsonrpc('Settings.GetSettingValue', {'setting': 'lookandfeel.skinzoom'})
    try:
        current = int(res.get('result', {}).get('value', 0))
    except (TypeError, ValueError, AttributeError):
        current = 0
    nxt = ZOOM_ALLOWED[(ZOOM_ALLOWED.index(current) + 1) % len(ZOOM_ALLOWED)] if current in ZOOM_ALLOWED else 0
    set_zoom(nxt)
    if nxt:
        xbmc.executebuiltin('Skin.SetString(sorbetto_zoom,%d)' % nxt)
    else:
        xbmc.executebuiltin('Skin.Reset(sorbetto_zoom)')


def lang_toggle():
    target = 'resource.language.en_gb' if menu.lang() == 'el' else 'resource.language.el_gr'
    xbmc.executebuiltin('SetGUILanguage(%s)' % target)


def main():
    handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action', 'menu')

    if action == 'theme':
        set_theme(params.get('name', ''))
    elif action == 'zoom':
        set_zoom(params.get('v'))
    elif action == 'zoomnext':
        zoom_next()
    elif action == 'langtoggle':
        lang_toggle()
    elif action == 'editor':
        from resources.lib import editor
        editor.run()
    elif handle < 0:
        xbmc.log('[Sorbetto Helper] άγνωστη εντολή: %s' % action, xbmc.LOGDEBUG)
    elif action == 'menu':
        list_menu(handle)
    elif action == 'bgcats':
        list_categories(handle)
    elif action == 'bgs':
        list_backgrounds(handle, params.get('cat', ''))
    else:
        # Τα κουμπιά εκτελούνται από το skin· εδώ δεν κάνουμε τίποτα.
        xbmcplugin.endOfDirectory(handle, succeeded=False)


if __name__ == '__main__':
    main()
