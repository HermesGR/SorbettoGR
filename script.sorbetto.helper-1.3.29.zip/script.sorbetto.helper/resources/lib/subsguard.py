# -*- coding: utf-8 -*-
"""Διπλοί υπότιτλοι στην ελληνική πηγή «GRS | Dubbed/Subbed (Greek)».

Η πηγή αυτή (script.module.grs μέσω του blackscrapers, GR-SUB-DUB) έχει τους ελληνικούς
υπότιτλους ΜΕΣΑ στην εικόνα. Το Blacklodge όμως κατεβάζει σε κάθε αναπαραγωγή και υπότιτλους
από το OpenSubtitles (TemporarySubs, player.py → opensubtitles.getSubs), οπότε φαίνονταν δύο φορές.

Εδώ: σε κάθε αναπαραγωγή που έρχεται από το GRS (η ροή του περνά από τον τοπικό proxy του
GRS 127.0.0.1:23455 ή από το coverapi), για 90 δευτερόλεπτα από την αρχή:
- αν η πηγή δεν είχε δικούς της υπότιτλους (άρα είναι μέσα στην εικόνα) και εμφανιστούν
  υπότιτλοι, τους κρύβουμε·
- αν η πηγή είχε δικούς της (μαλακούς) υπότιτλους, ξαναδιαλέγουμε εκείνους.
Ο χρήστης μπορεί πάντα να τους ξανανάψει από τις ρυθμίσεις υποτίτλων· μετά τα 90 δευτερόλεπτα
δεν τους ξαναπειράζουμε.
"""
import threading
import time

import xbmc

from resources.lib import menu

GRS_MARKS = ('127.0.0.1:23455', 'coverapi', 'grsub_graudio')
WATCH_SECONDS = 90


def _playing_paths(player):
    paths = []
    try:
        paths.append(player.getPlayingFile())
    except RuntimeError:
        pass
    try:
        paths.append(player.getPlayingItem().getPath())
    except (RuntimeError, AttributeError):
        pass
    paths.append(xbmc.getInfoLabel('Player.Filenameandpath'))
    return ' '.join(p for p in paths if p).lower()


def is_grs(player):
    text = _playing_paths(player)
    return any(m in text for m in GRS_MARKS)


def _streams(player):
    try:
        return list(player.getAvailableSubtitleStreams() or [])
    except RuntimeError:
        return []


def _guard(player, token):
    """Τρέχει σε δικό του νήμα για μία αναπαραγωγή."""
    own = len(_streams(player))  # υπότιτλοι της ίδιας της πηγής, πριν προλάβει το Blacklodge
    menu.log('υπότιτλοι: πηγή GRS (%d δικοί της υπότιτλοι)' % own)
    end = time.time() + WATCH_SECONDS
    acted = False
    while time.time() < end and player.token == token and player.isPlayingVideo():
        streams = _streams(player)
        if len(streams) > own and xbmc.getCondVisibility('VideoPlayer.SubtitlesEnabled'):
            if own == 0:
                player.showSubtitles(False)
                if not acted:
                    menu.log('υπότιτλοι: η πηγή GRS τους έχει μέσα στην εικόνα, κρύφτηκαν οι εξωτερικοί')
            else:
                player.setSubtitleStream(0)
                if not acted:
                    menu.log('υπότιτλοι: η πηγή GRS έχει δικούς της, ξαναμπήκαν αυτοί')
            acted = True
        xbmc.sleep(1000)


class SubsGuard(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.token = 0

    def onAVStarted(self):
        self.token += 1
        try:
            if not self.isPlayingVideo() or not is_grs(self):
                return
        except RuntimeError:
            return
        threading.Thread(target=_guard, args=(self, self.token), daemon=True).start()

    def onPlayBackStopped(self):
        self.token += 1

    def onPlayBackEnded(self):
        self.token += 1
