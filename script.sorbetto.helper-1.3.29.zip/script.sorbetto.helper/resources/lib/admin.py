# -*- coding: utf-8 -*-
"""Το κλειδί διαχειριστή ισχύει ΜΟΝΟ στο box όπου έγινε η σύνδεση.

Το κλειδί αποθηκεύεται στις ρυθμίσεις του βοηθού (userdata), που ΑΝΤΙΓΡΑΦΟΝΤΑΙ μέσα σε κάθε build.
Γι' αυτό στη σύνδεση γράφουμε κι ένα τυχαίο «σήμα» σε δύο μέρη: στις ρυθμίσεις (admin_dev) και
σε αρχείο στον φάκελο temp του Kodi, που δεν μπαίνει στο build και δεν σβήνεται στην εκκίνηση
(Util.cpp: σβήνονται μόνο προσωρινοί υπότιτλοι). Αν τα δύο δεν ταιριάζουν, το κλειδί ήρθε από
άλλο box: το σβήνουμε και η «Επεξεργασία μενού» κρύβεται.
"""
import os
import uuid

import xbmcvfs

from resources.lib import menu

MARKER = 'special://temp/sorbetto_admin.id'


def _marker_path():
    return xbmcvfs.translatePath(MARKER)


def _read_marker():
    try:
        with open(_marker_path(), 'r', encoding='utf-8') as fh:
            return fh.read().strip()
    except OSError:
        return ''


def key():
    return menu.ADDON.getSettingString('admin_key').strip()


def bind(new_key):
    """Μετά από επιτυχημένη σύνδεση: κλειδί + σήμα αυτού του box."""
    token = uuid.uuid4().hex
    path = _marker_path()
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(token)
    menu.ADDON.setSettingString('admin_dev', token)
    menu.ADDON.setSettingString('admin_key', new_key)


def clear():
    menu.ADDON.setSettingString('admin_key', '')
    menu.ADDON.setSettingString('admin_dev', '')
    try:
        os.remove(_marker_path())
    except OSError:
        pass


def valid():
    """True μόνο αν υπάρχει κλειδί ΚΑΙ ανήκει σε αυτό το box."""
    if not key():
        return False
    token = menu.ADDON.getSettingString('admin_dev').strip()
    return bool(token) and token == _read_marker()


def guard():
    """Στην εκκίνηση: κλειδί από άλλο box (π.χ. μέσα από το build) σβήνεται. Επιστρέφει valid()."""
    if key() and not valid():
        menu.log('κλειδί διαχειριστή από άλλο box: διαγράφηκε')
        clear()
        return False
    return valid()
