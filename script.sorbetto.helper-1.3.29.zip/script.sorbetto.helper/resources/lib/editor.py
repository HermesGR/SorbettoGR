# -*- coding: utf-8 -*-
"""Επεξεργασία του μενού μέσα από το Kodi (μόνο για τον διαχειριστή).

Ο διαχειριστής περιηγείται στα πρόσθετα με το τηλεχειριστήριο και διαλέγει φάκελο,
όπως στο Aeon Nox. Με την «Αποθήκευση» το μενού στέλνεται στο WordPress με το
κλειδί διαχειριστή και φτάνει σε όλους στην επόμενη εκκίνηση τους.
"""
import json
import time
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcgui

from resources.lib import admin, menu

DIALOG = xbmcgui.Dialog()
ICON_PATH = 'special://skin/media/sorbetto/icons/%s.png'
ICON_NAMES = {
    'home': ('Αρχική', 'Home'), 'tv': ('Τηλεόραση / Σειρές', 'TV / Series'), 'mic': ('Εκπομπές', 'Shows'),
    'kid': ('Παιδικά', 'Kids'), 'ball': ('Αθλητικά', 'Sports'), 'live': ('Live', 'Live'),
    'radio': ('Ραδιόφωνο', 'Radio'), 'film': ('Ταινίες', 'Movies'), 'music': ('Μουσική', 'Music'),
    'star': ('Αγαπημένα', 'Favourites'), 'search': ('Αναζήτηση', 'Search'), 'folder': ('Φάκελος', 'Folder'),
    'play': ('Αναπαραγωγή', 'Play'), 'globe': ('Διαδίκτυο', 'Web'), 'info': ('Πληροφορίες', 'Info'),
    'cog': ('Ρυθμίσεις', 'Settings'),
}
KODI_ACTIONS = [
    (('Ρυθμίσεις Kodi', 'Kodi settings'), 'ActivateWindow(Settings)', 'cog'),
    (('Αγαπημένα', 'Favourites'), 'ActivateWindow(Favourites)', 'star'),
    (('Πρόσθετα', 'Add-ons'), 'ActivateWindow(AddonBrowser)', 'folder'),
    (('Ταινίες (βιβλιοθήκη)', 'Movies (library)'), 'ActivateWindow(Videos,videodb://movies/titles/,return)', 'film'),
    (('Σειρές (βιβλιοθήκη)', 'TV shows (library)'), 'ActivateWindow(Videos,videodb://tvshows/titles/,return)', 'tv'),
    (('Μουσική (βιβλιοθήκη)', 'Music (library)'), 'ActivateWindow(Music,musicdb://,return)', 'music'),
    (('Live TV (PVR)', 'Live TV (PVR)'), 'ActivateWindow(TVChannels)', 'live'),
    (('Ραδιόφωνο (PVR)', 'Radio (PVR)'), 'ActivateWindow(RadioChannels)', 'radio'),
    (('Καιρός', 'Weather'), 'ActivateWindow(Weather)', 'globe'),
    (('Αρχεία', 'File manager'), 'ActivateWindow(FileManager)', 'folder'),
]
SHOWS = [('', ('Και στις δύο γλώσσες', 'Both languages')), ('el', ('Μόνο Ελληνικά', 'Greek only')),
         ('en', ('Μόνο Αγγλικά', 'English only'))]


def t(el, en):
    return el if menu.lang() == 'el' else en


# ------------------------------------------------------------------ δίκτυο

def _key():
    # κλειδί που ήρθε από άλλο box (π.χ. μέσα σε build) δεν χρησιμοποιείται ποτέ
    return admin.key() if admin.valid() else ''


def _base():
    """https://.../wp-json/sorbetto/v1 από τη διεύθυνση μενού."""
    url = menu.ADDON.getSettingString('menu_url').split('?')[0].rstrip('/')
    return url[:-len('/menu')] if url.endswith('/menu') else url


def _get_json(url, method='GET', body=None, headers=None):
    data = json.dumps(body, ensure_ascii=False).encode('utf-8') if body is not None else None
    hdr = {'User-Agent': 'Sorbetto-Helper/1.3', 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-cache'}
    hdr.update(headers or {})
    with urlopen(Request(url, data=data, method=method, headers=hdr), timeout=15) as resp:
        return json.loads(resp.read(2 * 1024 * 1024).decode('utf-8'))


def _request(method, body=None):
    """Το κλειδί πάει και στην κεφαλίδα και στο πεδίο key: κάποιοι servers πετάνε τις ειδικές κεφαλίδες."""
    url = _base() + '/menu'
    if method == 'GET':
        url += '?' + urlencode({'key': _key(), '_': int(time.time())})
    else:
        body = dict(body or {}, key=_key())
    data = json.dumps(body, ensure_ascii=False).encode('utf-8') if body is not None else None
    req = Request(url, data=data, method=method, headers={
        'User-Agent': 'Sorbetto-Helper/1.3',
        'Content-Type': 'application/json; charset=utf-8',
        'X-Sorbetto-Key': _key(),
        'Cache-Control': 'no-cache',
    })
    with urlopen(req, timeout=15) as resp:
        return json.loads(resp.read(2 * 1024 * 1024).decode('utf-8'))


def load_admin_items():
    """Όλα τα κουμπιά, και τα κρυφά, με τύπο και στόχο όπως είναι στο WordPress."""
    data = _request('GET')
    if not isinstance(data, dict) or 'admin' not in data:
        raise RuntimeError(t('Το WordPress έχει παλιά έκδοση του Sorbetto Menu Manager. Ανέβασε την 1.3.1.',
                             'WordPress runs an old Sorbetto Menu Manager. Install version 1.3.1.'))
    if data.get('admin') is not True:
        raise PermissionError(t('Το WordPress δεν δέχτηκε το κλειδί αυτού του Kodi.', 'WordPress did not accept the key of this Kodi.'))
    items = data.get('items')
    if not isinstance(items, list):
        raise ValueError('bad menu')
    out = []
    for it in items:
        if isinstance(it, dict) and it.get('label'):
            out.append({k: it.get(k, '') for k in (
                'id', 'label', 'label_en', 'icon', 'type', 'target', 'widget', 'widget_label',
                'widget_label_en', 'description', 'description_en', 'show')})
            out[-1]['enabled'] = 1 if it.get('enabled', 1) else 0
    return out


def save_items(items):
    return _request('POST', {'items': items})


# ------------------------------------------------------------------ Kodi

def busy(on):
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)' if on else 'Dialog.Close(busydialognocancel)')


def addons(kind):
    res = menu.jsonrpc('Addons.GetAddons', {'type': kind, 'enabled': True, 'properties': ['name', 'thumbnail']})
    found = (res.get('result') or {}).get('addons') or []
    return sorted(found, key=lambda a: a.get('name', '').lower())


def directory(path, media):
    busy(True)
    try:
        res = menu.jsonrpc('Files.GetDirectory', {'directory': path, 'media': media,
                                                  'properties': ['title', 'thumbnail', 'file']})
    finally:
        busy(False)
    return (res.get('result') or {}).get('files') or []


def li(label, icon='', label2=''):
    item = xbmcgui.ListItem(label=label, label2=label2, offscreen=True)
    if icon:
        item.setArt({'icon': icon, 'thumb': icon})
    return item


def choose_addon(kind):
    found = addons(kind)
    if not found:
        DIALOG.ok('Sorbetto', t('Δεν βρέθηκαν πρόσθετα αυτού του είδους.', 'No add-ons of this kind were found.'))
        return None
    i = DIALOG.select(t('Διάλεξε πρόσθετο', 'Choose an add-on'),
                      [li(a.get('name', a['addonid']), a.get('thumbnail', ''), a['addonid']) for a in found],
                      useDetails=True)
    return found[i] if i >= 0 else None


def browse(path, media, title):
    """Περιήγηση σε φακέλους. Επιστρέφει (διαδρομή, όνομα) ή None."""
    stack = [(path, title)]
    while stack:
        cur, name = stack[-1]
        folders = [f for f in directory(cur, media) if f.get('filetype') == 'directory']
        rows = [li('✔ ' + t('Αυτός ο φάκελος: ', 'This folder: ') + name)]
        rows += [li(f.get('label') or f.get('title') or f.get('file'), f.get('thumbnail', '')) for f in folders]
        i = DIALOG.select(name, rows, useDetails=True)
        if i < 0:
            stack.pop()                 # Πίσω: ένας φάκελος πάνω (ή ακύρωση στην αρχή)
            continue
        if i == 0:
            return cur, name
        f = folders[i - 1]
        stack.append((f['file'], f.get('label') or name))
    return None


def favourites():
    res = menu.jsonrpc('Favourites.GetFavourites', {'properties': ['window', 'windowparameter', 'path', 'thumbnail']})
    return (res.get('result') or {}).get('favourites') or []


def favourite_target(fav):
    kind = fav.get('type')
    if kind == 'window' and fav.get('windowparameter'):
        return 'kodi', 'ActivateWindow(%s,"%s",return)' % (fav.get('window'), fav['windowparameter'])
    if kind == 'window':
        return 'kodi', 'ActivateWindow(%s)' % fav.get('window')
    if kind == 'media' and fav.get('path'):
        return 'kodi', 'PlayMedia("%s")' % fav['path']
    if kind == 'script' and fav.get('path'):
        return 'addon', fav['path']
    if kind == 'androidapp' and fav.get('path'):
        return 'kodi', 'StartAndroidActivity(%s)' % fav['path'].replace('androidapp://sources/apps/', '')
    return None


# ------------------------------------------------------------------ επιλογή στόχου

def pick_target():
    """Τι ανοίγει το κουμπί. Επιστρέφει (type, target, όνομα, εικονίδιο) ή None."""
    opts = [
        ('video', t('Πρόσθετο βίντεο (με επιλογή φακέλου)', 'Video add-on (pick a folder)')),
        ('music', t('Πρόσθετο ήχου (με επιλογή φακέλου)', 'Audio add-on (pick a folder)')),
        ('program', t('Πρόγραμμα ή script', 'Program or script')),
        ('fav', t('Από τα Αγαπημένα του Kodi', 'From Kodi favourites')),
        ('kodi', t('Παράθυρο του Kodi (Ρυθμίσεις, Καιρός…)', 'Kodi window (Settings, Weather…)')),
    ]
    if xbmc.getCondVisibility('System.Platform.Android'):
        opts.append(('android', t('Εφαρμογή Android', 'Android app')))
    opts.append(('manual', t('Γράψε διαδρομή ή εντολή με το χέρι', 'Type a path or command')))
    i = DIALOG.select(t('Τι θα ανοίγει;', 'What should it open?'), [o[1] for o in opts])
    if i < 0:
        return None
    kind = opts[i][0]

    if kind in ('video', 'music'):
        a = choose_addon('xbmc.addon.video' if kind == 'video' else 'xbmc.addon.audio')
        if not a:
            return None
        got = browse('plugin://%s/' % a['addonid'], 'video' if kind == 'video' else 'music', a.get('name', ''))
        return (kind, got[0], got[1], '') if got else None

    if kind == 'program':
        found = addons('xbmc.addon.executable') + addons('xbmc.python.script')
        seen, uniq = set(), []
        for a in found:
            if a['addonid'] not in seen:
                seen.add(a['addonid'])
                uniq.append(a)
        if not uniq:
            DIALOG.ok('Sorbetto', t('Δεν βρέθηκαν προγράμματα.', 'No programs were found.'))
            return None
        j = DIALOG.select(t('Διάλεξε πρόγραμμα', 'Choose a program'),
                          [li(a.get('name', a['addonid']), a.get('thumbnail', ''), a['addonid']) for a in uniq],
                          useDetails=True)
        return ('addon', uniq[j]['addonid'], uniq[j].get('name', ''), '') if j >= 0 else None

    if kind == 'fav':
        favs = [f for f in favourites() if favourite_target(f)]
        if not favs:
            DIALOG.ok('Sorbetto', t('Δεν υπάρχουν αγαπημένα. Πρόσθεσε πρώτα στα Αγαπημένα ό,τι θέλεις (μενού επιλογών → Προσθήκη στα αγαπημένα).',
                                    'There are no favourites yet. Add what you want to Favourites first.'))
            return None
        j = DIALOG.select(t('Διάλεξε αγαπημένο', 'Choose a favourite'),
                          [li(f.get('title', ''), f.get('thumbnail', '')) for f in favs], useDetails=True)
        if j < 0:
            return None
        typ, target = favourite_target(favs[j])
        return typ, target, favs[j].get('title', ''), ''

    if kind == 'kodi':
        j = DIALOG.select(t('Παράθυρο του Kodi', 'Kodi window'),
                          [li(t(*a[0]), ICON_PATH % a[2]) for a in KODI_ACTIONS], useDetails=True)
        return ('kodi', KODI_ACTIONS[j][1], t(*KODI_ACTIONS[j][0]), KODI_ACTIONS[j][2]) if j >= 0 else None

    if kind == 'android':
        apps = [f for f in directory('androidapp://sources/apps/', 'files') if f.get('file')]
        if not apps:
            return None
        j = DIALOG.select(t('Εφαρμογή Android', 'Android app'),
                          [li(f.get('label', ''), f.get('thumbnail', '')) for f in apps], useDetails=True)
        if j < 0:
            return None
        pkg = apps[j]['file'].replace('androidapp://sources/apps/', '').strip('/')
        return 'kodi', 'StartAndroidActivity(%s)' % pkg, apps[j].get('label', ''), ''

    text = DIALOG.input(t('Διαδρομή plugin:// ή εντολή Kodi', 'plugin:// path or Kodi command'))
    if not text:
        return None
    if text.startswith('plugin://plugin.audio.'):
        return 'music', text, '', ''
    if text.startswith('plugin://'):
        return 'video', text, '', ''
    return 'kodi', text, '', ''


def pick_widget():
    """Η σειρά με αφίσες. Επιστρέφει (διαδρομή, όνομα), ('', '') για καμία, ή None για ακύρωση."""
    opts = [t('Φάκελος από πρόσθετο βίντεο', 'Folder of a video add-on'),
            t('Φάκελος από πρόσθετο ήχου', 'Folder of an audio add-on'),
            t('Από τα Αγαπημένα του Kodi', 'From Kodi favourites'),
            t('Χωρίς σειρά με αφίσες', 'No poster row')]
    i = DIALOG.select(t('Σειρά με αφίσες', 'Poster row'), opts)
    if i < 0:
        return None
    if i == 3:
        return '', ''
    if i in (0, 1):
        a = choose_addon('xbmc.addon.video' if i == 0 else 'xbmc.addon.audio')
        if not a:
            return None
        return browse('plugin://%s/' % a['addonid'], 'video' if i == 0 else 'music', a.get('name', ''))
    favs = [f for f in favourites() if f.get('type') == 'window' and f.get('windowparameter')]
    if not favs:
        DIALOG.ok('Sorbetto', t('Δεν υπάρχουν αγαπημένοι φάκελοι.', 'There are no favourite folders.'))
        return None
    j = DIALOG.select(t('Διάλεξε αγαπημένο', 'Choose a favourite'),
                      [li(f.get('title', ''), f.get('thumbnail', '')) for f in favs], useDetails=True)
    return (favs[j]['windowparameter'], favs[j].get('title', '')) if j >= 0 else None


def pick_icon(current):
    names = list(ICON_NAMES)
    pre = names.index(current) if current in names else -1
    i = DIALOG.select(t('Εικονίδιο', 'Icon'), [li(t(*ICON_NAMES[n]), ICON_PATH % n) for n in names],
                      useDetails=True, preselect=pre)
    return names[i] if i >= 0 else None


# ------------------------------------------------------------------ επεξεργασία

def short(text, n=48):
    text = text or '—'
    return text if len(text) <= n else text[:n - 1] + '…'


def edit_text(item, key, heading):
    value = DIALOG.input(heading, defaultt=item.get(key, ''))
    if value or DIALOG.yesno('Sorbetto', t('Να μείνει κενό;', 'Leave it empty?')):
        item[key] = value.strip()
        return True
    return False


def edit_item(items, idx):
    """Επιστρέφει True αν άλλαξε κάτι."""
    changed = False
    while 0 <= idx < len(items):
        it = items[idx]
        show = dict(SHOWS).get(it.get('show', ''), SHOWS[0][1])
        rows = [
            ('done', t('✔ Έτοιμο — πίσω στη λίστα', '✔ Done — back to the list'), ''),
            ('label', t('Όνομα', 'Name'), it.get('label')),
            ('label_en', t('Όνομα στα Αγγλικά', 'English name'), it.get('label_en')),
            ('icon', t('Εικονίδιο', 'Icon'), t(*ICON_NAMES.get(it.get('icon'), ICON_NAMES['folder']))),
            ('target', t('Τι ανοίγει', 'Opens'), it.get('target')),
            ('widget', t('Σειρά με αφίσες', 'Poster row'), it.get('widget')),
            ('widget_label', t('Τίτλος σειράς', 'Row title'), it.get('widget_label')),
            ('widget_label_en', t('Τίτλος σειράς στα Αγγλικά', 'Row title (English)'), it.get('widget_label_en')),
            ('description', t('Περιγραφή', 'Description'), it.get('description')),
            ('description_en', t('Περιγραφή στα Αγγλικά', 'Description (English)'), it.get('description_en')),
            ('show', t('Γλώσσα', 'Language'), t(*show)),
            ('enabled', t('Εμφάνιση', 'Visible'), t('Ναι', 'Yes') if it.get('enabled', 1) else t('Όχι (κρυφό)', 'No (hidden)')),
            ('up', t('▲ Μετακίνηση πάνω', '▲ Move up'), ''),
            ('down', t('▼ Μετακίνηση κάτω', '▼ Move down'), ''),
            ('delete', t('✖ Διαγραφή κουμπιού', '✖ Delete button'), ''),
        ]
        i = DIALOG.select(it.get('label') or t('Νέο κουμπί', 'New button'),
                          [li(r[1], ICON_PATH % it.get('icon', 'folder') if r[0] == 'icon' else '', short(r[2])) for r in rows],
                          useDetails=True)
        if i < 0 or rows[i][0] == 'done':
            return changed
        key = rows[i][0]
        if key in ('label', 'label_en', 'widget_label', 'widget_label_en', 'description', 'description_en'):
            changed |= edit_text(it, key, rows[i][1])
        elif key == 'icon':
            icon = pick_icon(it.get('icon'))
            if icon:
                it['icon'] = icon
                changed = True
        elif key == 'target':
            got = pick_target()
            if got:
                it['type'], it['target'] = got[0], got[1]
                if not it.get('label') and got[2]:
                    it['label'] = got[2]
                if got[3] and it.get('icon', 'folder') == 'folder':
                    it['icon'] = got[3]
                changed = True
        elif key == 'widget':
            got = pick_widget()
            if got is not None:
                it['widget'] = got[0]
                if got[0] and not it.get('widget_label'):
                    it['widget_label'] = got[1]
                changed = True
        elif key == 'show':
            j = DIALOG.select(t('Γλώσσα', 'Language'), [t(*s[1]) for s in SHOWS])
            if j >= 0:
                it['show'] = SHOWS[j][0]
                changed = True
        elif key == 'enabled':
            it['enabled'] = 0 if it.get('enabled', 1) else 1
            changed = True
        elif key == 'up' and idx > 0:
            items[idx - 1], items[idx] = items[idx], items[idx - 1]
            idx -= 1
            changed = True
        elif key == 'down' and idx < len(items) - 1:
            items[idx + 1], items[idx] = items[idx], items[idx + 1]
            idx += 1
            changed = True
        elif key == 'delete':
            if DIALOG.yesno('Sorbetto', t('Να διαγραφεί το «%s»;', 'Delete “%s”?') % (it.get('label') or '?')):
                del items[idx]
                return True
    return changed


def new_item():
    got = pick_target()
    if not got:
        return None
    item = {'id': '', 'label': got[2], 'label_en': '', 'icon': got[3] or 'folder', 'type': got[0], 'target': got[1],
            'widget': '', 'widget_label': '', 'widget_label_en': '', 'description': '', 'description_en': '',
            'show': '', 'enabled': 1}
    name = DIALOG.input(t('Όνομα κουμπιού', 'Button name'), defaultt=item['label'])
    item['label'] = (name or item['label'] or t('Νέο κουμπί', 'New button')).strip()
    if DIALOG.yesno('Sorbetto', t('Να έχει σειρά με αφίσες δεξιά;', 'Add a poster row on the right?')):
        w = pick_widget()
        if w:
            item['widget'], item['widget_label'] = w[0], w[1]
    return item


def publish(items):
    if not any(i.get('label') for i in items):
        DIALOG.ok('Sorbetto', t('Το μενού δεν μπορεί να μείνει άδειο.', 'The menu cannot be empty.'))
        return False
    busy(True)
    try:
        res = save_items(items)
    except Exception as exc:
        busy(False)
        menu.log('η αποθήκευση απέτυχε: %s' % exc, xbmc.LOGWARNING)
        DIALOG.ok('Sorbetto', t('Η αποθήκευση απέτυχε. Έλεγξε το internet και το κλειδί διαχειριστή.\n\n',
                                'Saving failed. Check the internet connection and the admin key.\n\n') + str(exc)[:200])
        return False
    busy(False)
    fresh = menu.fetch(menu.ADDON.getSettingString('menu_url'))
    if fresh:
        menu.save(fresh)
        xbmcgui.Window(10000).setProperty(menu.PROP_VERSION, str(fresh['version']))
    DIALOG.notification('Sorbetto', t('Το μενού αποθηκεύτηκε (%s κουμπιά)', 'Menu saved (%s buttons)') % res.get('count', len(items)),
                        xbmcgui.NOTIFICATION_INFO, 4000)
    return True


def pair():
    """Σύνδεση χωρίς πληκτρολόγηση: δείχνουμε κωδικό, ο διαχειριστής πατά «Έγκριση» στο WordPress."""
    try:
        start = _get_json(_base() + '/pair', method='POST', body={})
        code, poll = start['code'], start['poll']
        wait = int(start.get('expires', 600))
    except Exception as exc:
        DIALOG.ok('Sorbetto', t('Δεν ξεκίνησε η σύνδεση με το WordPress.\n\n', 'Could not start pairing with WordPress.\n\n') + str(exc)[:200])
        return False
    msg = t('Κωδικός σύνδεσης: [B]%s[/B]\nΣτο WordPress: Sorbetto → Μενού → «Έγκριση» δίπλα στον ίδιο κωδικό.',
            'Pairing code: [B]%s[/B]\nIn WordPress: Sorbetto → Menu → “Approve” next to the same code.') % code
    progress = xbmcgui.DialogProgress()
    progress.create('Sorbetto', msg)
    began = time.time()
    try:
        while time.time() - began < wait:
            if progress.iscanceled():
                return False
            progress.update(int(100 * (time.time() - began) / wait), msg)
            try:
                st = _get_json(_base() + '/pair/status?' + urlencode({'poll': poll, '_': int(time.time())}))
            except Exception as exc:
                menu.log('pair status: %s' % exc, xbmc.LOGWARNING)
                st = {}
            if st.get('status') == 'approved' and st.get('key'):
                admin.bind(st['key'])
                xbmcgui.Window(10000).setProperty('sorbetto.admin', 'true')
                DIALOG.notification('Sorbetto', t('Το Kodi συνδέθηκε', 'This Kodi is now connected'), xbmcgui.NOTIFICATION_INFO, 3000)
                return True
            if st.get('status') == 'unknown':
                DIALOG.ok('Sorbetto', t('Ο κωδικός απορρίφθηκε ή έληξε.', 'The code was rejected or expired.'))
                return False
            xbmc.Monitor().waitForAbort(3)
    finally:
        progress.close()
    DIALOG.ok('Sorbetto', t('Ο κωδικός έληξε. Δοκίμασε ξανά.', 'The code expired. Try again.'))
    return False


def run():
    if not _key() and not pair():
        return
    busy(True)
    try:
        items = load_admin_items()
    except PermissionError as exc:
        busy(False)
        if DIALOG.yesno('Sorbetto', str(exc) + '\n\n' + t('Να γίνει νέα σύνδεση με κωδικό;', 'Pair again with a code?')):
            admin.clear()
            xbmcgui.Window(10000).clearProperty('sorbetto.admin')
            if pair():
                return run()
        return
    except Exception as exc:
        busy(False)
        DIALOG.ok('Sorbetto', t('Δεν διαβάστηκε το μενού από το WordPress.\n\n', 'Could not read the menu from WordPress.\n\n') + str(exc)[:200])
        return
    busy(False)
    dirty = False
    while True:
        # Οι ενέργειες πρώτες, για να μη χρειάζεται ψάξιμο· μετά τα κουμπιά του μενού.
        save_label = (t('💾 Αποθήκευση στο WordPress — υπάρχουν αλλαγές', '💾 Save to WordPress — unsaved changes') if dirty
                      else t('💾 Αποθήκευση στο WordPress', '💾 Save to WordPress'))
        actions = [('save', li(save_label)), ('new', li(t('+ Νέο κουμπί', '+ New button')))]
        actions += [('item', li('%d. %s' % (n + 1, it.get('label', '')), ICON_PATH % it.get('icon', 'folder'),
                                short(it.get('target')) + ('' if it.get('enabled', 1) else t('  · κρυφό', '  · hidden'))))
                    for n, it in enumerate(items)]
        actions.append(('close', li(t('✖ Έξοδος', '✖ Close'))))
        i = DIALOG.select(t('Επεξεργασία μενού', 'Edit menu'), [a[1] for a in actions], useDetails=True)
        kind = actions[i][0] if i >= 0 else 'close'
        if kind == 'new':
            it = new_item()
            if it:
                items.append(it)
                dirty = True
        elif kind == 'save':
            if publish(items):
                dirty = False
        elif kind == 'close':
            if not dirty or DIALOG.yesno('Sorbetto', t('Υπάρχουν αλλαγές που δεν αποθηκεύτηκαν. Έξοδος χωρίς αποθήκευση;',
                                                        'There are unsaved changes. Close without saving?')):
                return
        else:
            dirty |= edit_item(items, i - 2)
