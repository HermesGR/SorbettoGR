# -*- coding: utf-8 -*-
"""Ενημέρωση του skin Sorbetto από τον βοηθό, χωρίς τον μηχανισμό εγκατάστασης του Kodi.

Γιατί: όταν το Kodi αναβαθμίζει το skin που είναι ανοιχτό, πρώτα το ξεφορτώνει
(Skin.cpp, CSkinInfo::OnPreInstall -> UnloadSkin), μετά αντικαθιστά τα αρχεία και μετά το
ξαναφορτώνει (OnPostInstall -> ReloadSkin). Στα box μας αυτό κολλούσε ανάμεσα: έμενε κενό φόντο
μέχρι αναγκαστική διακοπή, σε κάθε αναβάθμιση του skin και στην πρώτη εκκίνηση μετά το build.
Αντίθετα, το απλό ReloadSkin (το ίδιο που κάνει η αλλαγή «Μέγεθος γραμμάτων») δουλεύει κανονικά.

Τι κάνουμε (μόνο σε Android):
1. Λέμε στο Kodi να ΜΗΝ αναβαθμίζει αυτόματα το skin (κανόνας USER_DISABLED_AUTO_UPDATE = 1
   στον πίνακα update_rules, ό,τι κάνει και ο διακόπτης «Αυτόματη ενημέρωση» στις πληροφορίες
   πρόσθετου). Το Kodi τον διαβάζει ξανά στο UpdateLocalAddons (AddonManager.cpp, FindAddons).
2. Κατεβάζουμε μόνοι μας τη νέα έκδοση (skin.json του Sorbetto Repository, όχι addons.xml), την ελέγχουμε και την
   ετοιμάζουμε δίπλα (addons/packages, φάκελος που το Kodi δεν σαρώνει για πρόσθετα).
3. Όταν ο χρήστης είναι στην αρχική, χωρίς αναπαραγωγή και χωρίς ανοιχτό παράθυρο διαλόγου,
   αλλάζουμε τον φάκελο με μια μετονομασία και κάνουμε ReloadSkin. Αν δεν βρεθεί τέτοια στιγμή,
   η νέα έκδοση μένει έτοιμη και μπαίνει στην επόμενη εκκίνηση.
Σε άλλες πλατφόρμες (π.χ. Windows, όπου δεν μετονομάζεται φάκελος με ανοιχτά αρχεία) ο κανόνας
αφαιρείται και το Kodi ενημερώνει το skin όπως πάντα.
"""
import hashlib
import json
import os
import re
import shutil
import sqlite3
import glob
import zipfile
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import menu

SKIN_ID = 'skin.sorbetto'
HELPER_ID = 'script.sorbetto.helper'
REPO_URL = 'https://hermesgr.github.io/SorbettoGR/'
RULE_NO_AUTO_UPDATE = 1
WAIT_IDLE_SECONDS = 30 * 60

ADDONS_DIR = xbmcvfs.translatePath('special://home/addons/')
STAGE_DIR = os.path.join(ADDONS_DIR, 'packages', 'sorbetto_stage')
OLD_DIR = os.path.join(ADDONS_DIR, 'packages', 'sorbetto_old')
SKIN_DIR = os.path.join(ADDONS_DIR, SKIN_ID)


def is_android():
    return xbmc.getCondVisibility('System.Platform.Android')


def _addons_db():
    folder = xbmcvfs.translatePath('special://database/')

    def number(path):
        digits = ''.join(ch for ch in os.path.basename(path) if ch.isdigit())
        return int(digits) if digits else -1

    dbs = sorted(glob.glob(os.path.join(folder, 'Addons*.db')), key=number)
    return dbs[-1] if dbs else None


def set_rule(enabled):
    """Βάζει (enabled=True) ή βγάζει τον κανόνα «χωρίς αυτόματη ενημέρωση» για το skin.
    Επιστρέφει True αν άλλαξε κάτι στη βάση (τότε χρειάζεται UpdateLocalAddons)."""
    db = _addons_db()
    if not db:
        return False
    try:
        con = sqlite3.connect(db, timeout=10)
        try:
            have = con.execute('SELECT COUNT(*) FROM update_rules WHERE addonID=? AND updateRule=?',
                               (SKIN_ID, RULE_NO_AUTO_UPDATE)).fetchone()[0] > 0
            if enabled and not have:
                con.execute('INSERT INTO update_rules (addonID, updateRule) VALUES (?, ?)',
                            (SKIN_ID, RULE_NO_AUTO_UPDATE))
            elif not enabled and have:
                con.execute('DELETE FROM update_rules WHERE addonID=? AND updateRule=?',
                            (SKIN_ID, RULE_NO_AUTO_UPDATE))
            else:
                return False
            con.commit()
        finally:
            con.close()
    except sqlite3.Error as exc:
        menu.log('skin: ο κανόνας ενημέρωσης δεν γράφτηκε (%s)' % exc, xbmc.LOGWARNING)
        return False
    menu.log('skin: αυτόματη ενημέρωση από το Kodi %s' % ('κλειστή' if enabled else 'ανοιχτή'))
    return True


def _version_tuple(v):
    return tuple(int(x) for x in re.findall(r'\d+', v or '0'))


def _installed_version(addon_id):
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo('version')
    except RuntimeError:
        return ''


def _get(url, timeout=20):
    req = Request(url, headers={'User-Agent': 'Kodi-SorbettoHelper', 'Cache-Control': 'no-cache'})
    with urlopen(req, timeout=timeout) as r:
        return r.read()


def latest_in_repo():
    """(έκδοση, διεύθυνση zip, md5) του skin από το skin.json του Sorbetto Repository.

    Το skin ΔΕΝ υπάρχει στο addons.xml του αποθετηρίου: έτσι το Kodi δεν βλέπει ποτέ ενημέρωση
    για το skin και δεν ξεκινά τη δική του αναβάθμιση (που κολλούσε), ούτε σε box με παλιό βοηθό
    ή σε νέα εγκατάσταση από παλιό build. Την ενημέρωση του skin την κάνει μόνο ο βοηθός."""
    data = json.loads(_get(REPO_URL + 'skin.json').decode('utf-8'))
    ver = str(data.get('version') or '')
    zipname = str(data.get('zip') or '')
    if not re.match(r'^\d+(\.\d+)*$', ver) or not re.match(r'^[A-Za-z0-9_.\-]+\.zip$', zipname):
        return None, None, None
    return ver, REPO_URL + zipname, str(data.get('md5') or '').lower()


def _requires_ok(addon_xml):
    """Αν το νέο skin θέλει νεότερο βοηθό, περιμένουμε να έρθει πρώτα αυτός (από το Kodi)."""
    m = re.search(r'<import\s+addon="%s"\s+version="([^"]+)"' % re.escape(HELPER_ID), addon_xml)
    if not m:
        return True
    return _version_tuple(_installed_version(HELPER_ID)) >= _version_tuple(m.group(1))


def stage(version, url, md5=''):
    """Κατεβάζει και ελέγχει το zip, το αποσυμπιέζει στο STAGE_DIR. True αν είναι έτοιμο."""
    tmp = os.path.join(ADDONS_DIR, 'packages', 'sorbetto_skin.zip')
    os.makedirs(os.path.dirname(tmp), exist_ok=True)
    blob = _get(url, timeout=60)
    if md5 and hashlib.md5(blob).hexdigest() != md5:
        raise ValueError('το md5 του zip δεν ταιριάζει με το skin.json')
    with open(tmp, 'wb') as f:
        f.write(blob)
    try:
        with zipfile.ZipFile(tmp) as z:
            if z.testzip() is not None:
                raise ValueError('χαλασμένο zip')
            names = z.namelist()
            if any(not n.startswith(SKIN_ID + '/') or '..' in n.split('/') for n in names):
                raise ValueError('άγνωστα αρχεία μέσα στο zip')
            addon_xml = z.read(SKIN_ID + '/addon.xml').decode('utf-8', 'replace')
            ver = re.search(r'<addon\s[^>]*version="([^"]+)"', addon_xml)
            if not ver or ver.group(1) != version or ('id="%s"' % SKIN_ID) not in addon_xml:
                raise ValueError('λάθος έκδοση μέσα στο zip')
            if not _requires_ok(addon_xml):
                menu.log('skin %s: περιμένει νεότερο βοηθό, ξανά στην επόμενη εκκίνηση' % version)
                return False
            shutil.rmtree(STAGE_DIR, ignore_errors=True)
            z.extractall(STAGE_DIR)
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    return os.path.isfile(os.path.join(STAGE_DIR, SKIN_ID, 'addon.xml'))


def _staged_version():
    try:
        with open(os.path.join(STAGE_DIR, SKIN_ID, 'addon.xml'), encoding='utf-8') as f:
            m = re.search(r'<addon\s[^>]*version="([^"]+)"', f.read())
        return m.group(1) if m else ''
    except OSError:
        return ''


def _idle():
    return (xbmc.getCondVisibility('Window.IsActive(home)') and
            not xbmc.getCondVisibility('Player.HasMedia') and
            not xbmc.getCondVisibility('System.HasActiveModalDialog') and
            not xbmc.getCondVisibility('Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)'))


def swap_and_reload():
    """Αλλάζει τον φάκελο του skin με μία μετονομασία και ξαναφορτώνει. True αν έγινε."""
    staged = os.path.join(STAGE_DIR, SKIN_ID)
    shutil.rmtree(OLD_DIR, ignore_errors=True)
    try:
        os.rename(SKIN_DIR, OLD_DIR)
    except OSError as exc:
        menu.log('skin: δεν μετακινήθηκε ο παλιός φάκελος (%s)' % exc, xbmc.LOGWARNING)
        return False
    try:
        os.rename(staged, SKIN_DIR)
    except OSError as exc:
        menu.log('skin: δεν μπήκε ο νέος φάκελος (%s), επαναφορά' % exc, xbmc.LOGWARNING)
        os.rename(OLD_DIR, SKIN_DIR)
        return False
    shutil.rmtree(STAGE_DIR, ignore_errors=True)
    # το Kodi ξαναδιαβάζει το addon.xml (νέα έκδοση στη βάση) και μετά φορτώνει το νέο skin
    xbmc.executebuiltin('UpdateLocalAddons', True)
    xbmc.executebuiltin('ReloadSkin()')
    return True


def apply_rule():
    """Καλείται από το service πριν από τον έλεγχο ενημερώσεων. Επιστρέφει True αν άλλαξε ο
    κανόνας (τότε το service κάνει UpdateLocalAddons πριν από το UpdateAddonRepos)."""
    if not is_android():
        return set_rule(False)
    return set_rule(True)


def update(monitor):
    """Κατεβάζει/εφαρμόζει νέα έκδοση του skin. Τρέχει στο τέλος του service (μπορεί να περιμένει)."""
    if not is_android():
        return
    if xbmc.getSkinDir() != SKIN_ID:
        return
    current = _installed_version(SKIN_ID)
    try:
        version, url, md5 = latest_in_repo()
    except Exception as exc:  # χωρίς internet, το GitHub δεν απαντά ή δεν υπάρχει skin.json
        menu.log('skin: δεν διαβάστηκε το skin.json (%s)' % exc, xbmc.LOGWARNING)
        version, url, md5 = None, None, None
    if version and _version_tuple(version) > _version_tuple(current):
        if _staged_version() != version:
            try:
                if not stage(version, url, md5):
                    return
            except Exception as exc:
                menu.log('skin %s: δεν ετοιμάστηκε (%s)' % (version, exc), xbmc.LOGWARNING)
                shutil.rmtree(STAGE_DIR, ignore_errors=True)
                return
        menu.log('skin %s: έτοιμο, περιμένει την αρχική χωρίς αναπαραγωγή' % version)
    elif _version_tuple(_staged_version()) <= _version_tuple(current):
        shutil.rmtree(STAGE_DIR, ignore_errors=True)
        shutil.rmtree(OLD_DIR, ignore_errors=True)
        return
    target = _staged_version()
    if not target:
        return
    # λίγος χρόνος μετά την εκκίνηση: το Kodi αγνοεί το ReloadSkin όσο «αρχικοποιείται»
    # (ApplicationSkinHandling.cpp, m_bInitializing)
    if monitor.waitForAbort(20):
        return
    waited = 0
    while not monitor.abortRequested() and waited < WAIT_IDLE_SECONDS:
        # δύο συνεχόμενοι έλεγχοι, για να μη γίνει πάνω σε αλλαγή παραθύρου
        if _idle() and not monitor.waitForAbort(2) and _idle():
            if swap_and_reload():
                monitor.waitForAbort(8)
                shutil.rmtree(OLD_DIR, ignore_errors=True)
                menu.log('skin: ενημερώθηκε σε %s' % target)
                xbmcgui.Dialog().notification('Sorbetto', 'Η εμφάνιση ενημερώθηκε (%s)' % target,
                                              menu.ADDON_PATH + '/icon.png', 4000)
            return
        if monitor.waitForAbort(5):
            return
        waited += 7
    menu.log('skin %s: δεν βρέθηκε ήσυχη στιγμή, θα μπει στην επόμενη εκκίνηση' % target)
