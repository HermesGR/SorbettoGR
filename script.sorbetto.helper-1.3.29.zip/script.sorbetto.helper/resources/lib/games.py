# -*- coding: utf-8 -*-
"""«Retro Gaming»: δωρεάν παιχνίδια με ένα κλικ.

Τα παιχνίδια/πυρήνες είναι τα επίσημα πρόσθετα παιχνιδιών του Kodi (game.libretro.*, από το
επίσημο αποθετήριο του Kodi). Μπαίνουν ως εξαρτήσεις του βοηθού (addon.xml), οπότε το Kodi τα
εγκαθιστά μόνο του και διαλέγει μόνο του την έκδοση για 32 ή 64 bit.

Όσα χρειάζονται αρχεία δεδομένων (Freedoom, Cave Story, Wolfenstein 3D shareware) τα κατεβάζει το ίδιο το box την πρώτη φορά, από τις επίσημες σελίδες τους, στον φάκελο
του βοηθού (addon_data/script.sorbetto.helper/games/). Όλα είναι δωρεάν/ελεύθερα για διανομή.

Άνοιγμα: RunAddon(πυρήνας) για τα αυτόνομα παιχνίδια, RunAddon(πυρήνας, αρχείο) για τα άλλα
(AddonBuiltins.cpp: GAMEDLL → PlayMedia με SetGameClient).
"""
import os
import shutil
import time
import zipfile
from urllib.parse import quote

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import menu

MENU_ID = 'retrogaming'
LIST_URL = 'plugin://script.sorbetto.helper/?action=games'
WIDGET_URL = 'plugin://script.sorbetto.helper/?action=gameswidget'
GAME_URL = 'plugin://script.sorbetto.helper/?action=game&id=%s'
GAMES_DIR = os.path.join(menu.PROFILE, 'games')
UA = 'Mozilla/5.0 (Linux; Android 11) Sorbetto-Helper/1.3'

# Κουμπί της αρχικής, πάνω από τα «Αγαπημένα» (αν δεν υπάρχει ήδη στο μενού του WordPress).
MENU_ITEM = {
    'id': MENU_ID,
    'label': 'RETRO GAMING',
    'label_en': 'RETRO GAMING',
    'icon': 'play',
    'action': 'ActivateWindow(Programs,"%s",return)' % LIST_URL,
    'widget': WIDGET_URL,
    'widget_label': 'Παιχνίδια με ένα κλικ',
    'widget_label_en': 'One-click games',
    'description': 'Δωρεάν κλασικά παιχνίδια: Rick Dangerous, Doom, Wolfenstein 3D, Cave Story και άλλα.',
    'description_en': 'Free classic games: Rick Dangerous, Doom, Wolfenstein 3D, Cave Story and more.',
    'show': '',
}

# Αρχεία δεδομένων: (κλειδί φακέλου) → λήψεις. Κάθε λήψη: url(s), και τι πρέπει να υπάρχει μετά.
DATA = {
    'freedoom': {
        'size': 25,
        'files': [('https://github.com/freedoom/freedoom/releases/download/v0.13.0/freedoom-0.13.0.zip',)],
    },
    'cavestory': {
        'size': 5,
        'files': [('https://buildbot.libretro.com/assets/cores/Cave%20Story/Cave%20Story%20%28En%29.zip',
                   'http://buildbot.libretro.com/assets/cores/Cave%20Story/Cave%20Story%20%28En%29.zip')],
    },
    'wolf3d': {
        'size': 4,
        'files': [('https://maniacsvault.net/ecwolf/files/shareware/wolf3d14.zip',),
                  # μόνο για το ecwolf.pk3 (αρχείο της μηχανής ECWolf, ελεύθερο)
                  ('https://maniacsvault.net/ecwolf/files/ecwolf/1.x/ecwolf-1.4.2_x64.zip',)],
    },
}

# Τα παιχνίδια, με τη σειρά που εμφανίζονται.
# core: πρόσθετο του Kodi · data/find: αρχεία δεδομένων και ποιο αρχείο ανοίγει
GAMES = (
    {'id': 'xrick', 'core': 'game.libretro.xrick', 'label': 'Rick Dangerous',
     'el': 'Το κλασικό platform του 1989: ο Rick ξεφεύγει από παγίδες σε ναούς και κάστρα.',
     'en': 'The 1989 platform classic: Rick dodges traps in temples and castles.'},
    {'id': 'freedoom1', 'core': 'game.libretro.prboom', 'label': 'Freedoom: Phase 1 (Doom)',
     'data': 'freedoom', 'find': 'freedoom1.wad',
     'el': 'Το Doom με ελεύθερα γραφικά και πίστες. Λήψη ~25 MB την πρώτη φορά.',
     'en': 'Doom with free graphics and levels. ~25 MB download the first time.'},
    {'id': 'freedoom2', 'core': 'game.libretro.prboom', 'label': 'Freedoom: Phase 2 (Doom II)',
     'data': 'freedoom', 'find': 'freedoom2.wad',
     'el': 'Η συνέχεια, σε στυλ Doom II, με 32 πίστες.',
     'en': 'The sequel, Doom II style, with 32 levels.'},
    {'id': 'wolf3d', 'core': 'game.libretro.ecwolf', 'label': 'Wolfenstein 3D (shareware)',
     'data': 'wolf3d', 'find': 'vswap.wl1',
     'el': 'Το πρώτο FPS, το επίσημο δωρεάν επεισόδιο 1. Λήψη ~4 MB την πρώτη φορά.',
     'en': 'The first FPS, the official free episode 1. ~4 MB download the first time.'},
    {'id': 'cavestory', 'core': 'game.libretro.nx', 'label': 'Cave Story',
     'data': 'cavestory', 'find': 'doukutsu.exe',
     'el': 'Θρυλικό indie περιπέτειας και δράσης (NXEngine). Λήψη ~5 MB την πρώτη φορά.',
     'en': 'Legendary indie action-adventure (NXEngine). ~5 MB download the first time.'},
    {'id': 'mrboom', 'core': 'game.libretro.mrboom', 'label': 'Mr.Boom',
     'el': 'Bomberman για έως 8 παίκτες.',
     'en': 'Bomberman for up to 8 players.'},
    {'id': 'dinothawr', 'core': 'game.libretro.dinothawr', 'label': 'Dinothawr',
     'el': 'Γρίφοι στον πάγο: ελευθέρωσε τους φίλους του δεινοσαύρου.',
     'en': 'Ice puzzles: free the dinosaur\'s friends.'},
    {'id': '2048', 'core': 'game.libretro.2048', 'label': '2048',
     'el': 'Ένωσε τα ίδια νούμερα μέχρι το 2048.',
     'en': 'Merge equal numbers up to 2048.'},
    {'id': 'gong', 'core': 'game.libretro.gong', 'label': 'Gong (Pong)',
     'el': 'Το κλασικό Pong, για 1 ή 2 παίκτες.',
     'en': 'The classic Pong, for 1 or 2 players.'},
)
BY_ID = {g['id']: g for g in GAMES}

# Αφαιρέθηκαν στην 1.3.22: The Powder Toy, Beneath a Steel Sky, Flight of the Amazon Queen.
# Σε όσα box πρόλαβαν να μπουν, σβήνονται μία φορά (cleanup_removed, από το service).
REMOVED_CORES = ('game.libretro.thepowdertoy', 'game.libretro.scummvm')
REMOVED_DATA = ('bass', 'fotaq')


def cleanup_removed():
    """Σβήνει τα πρόσθετα και τα αρχεία των παιχνιδιών που αφαιρέθηκαν. Επιστρέφει True αν
    σβήστηκε πρόσθετο (τότε χρειάζεται UpdateLocalAddons: το Kodi βγάζει από τη βάση του όσα
    δεν υπάρχουν πια στον δίσκο, AddonMgr FindAddons → SyncInstalled)."""
    for key in REMOVED_DATA:
        shutil.rmtree(os.path.join(GAMES_DIR, key), ignore_errors=True)
        shutil.rmtree(os.path.join(GAMES_DIR, key + '.tmp'), ignore_errors=True)
    removed = False
    for core in REMOVED_CORES:
        folder = xbmcvfs.translatePath('special://home/addons/%s' % core)
        if os.path.isdir(folder):
            shutil.rmtree(folder, ignore_errors=True)
            shutil.rmtree(xbmcvfs.translatePath('special://profile/addon_data/%s' % core), ignore_errors=True)
            removed = not os.path.isdir(folder) or removed
            menu.log('παιχνίδια: αφαιρέθηκε το %s' % core)
    return removed

TEXT = {
    'el': {
        'dl': 'Λήψη αρχείων παιχνιδιού (μία φορά)…',
        'dlfail': 'Δεν ήταν δυνατή η λήψη. Ελέγξτε τη σύνδεση και δοκιμάστε ξανά.',
        'install': 'Γίνεται εγκατάσταση του παιχνιδιού…',
        'nocore': 'Το παιχνίδι δεν είναι ακόμα εγκατεστημένο. Δοκιμάστε ξανά σε λίγο.',
        'nofile': 'Τα αρχεία του παιχνιδιού δεν βρέθηκαν μετά τη λήψη.',
    },
    'en': {
        'dl': 'Downloading game files (one time)…',
        'dlfail': 'The download failed. Check your connection and try again.',
        'install': 'Installing the game…',
        'nocore': 'The game is not installed yet. Please try again shortly.',
        'nofile': 'The game files were not found after the download.',
    },
}


def t(key):
    return TEXT[menu.lang()][key]


def has(addon_id):
    return xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id)


def icon(core):
    res = menu.jsonrpc('Addons.GetAddonDetails', {'addonid': core, 'properties': ['thumbnail', 'fanart']})
    addon = ((res or {}).get('result') or {}).get('addon') or {}
    return addon.get('thumbnail') or 'DefaultAddonGame.png', addon.get('fanart') or ''


def visible():
    """Παιχνίδια που φαίνονται: όσα έχουν εγκατεστημένο πυρήνα."""
    return [g for g in GAMES if has(g['core'])]


def favourite_path(game_id):
    """Διαδρομή για το widget: το Kodi εκτελεί την εντολή που είναι μέσα (FavouritesURL.cpp),
    όπως ένα αγαπημένο. Έτσι το κλικ στο widget ανοίγει το παιχνίδι κατευθείαν."""
    cmd = 'RunPlugin("%s")' % (GAME_URL % game_id)
    return 'favourites://' + quote(cmd, safe='')


# ---------------------------------------------------------------- λήψη αρχείων

def _safe_extract(zf, dest):
    root = os.path.realpath(dest)
    for info in zf.infolist():
        target = os.path.realpath(os.path.join(dest, info.filename))
        if not (target == root or target.startswith(root + os.sep)):
            raise ValueError('μη ασφαλής διαδρομή στο zip: %s' % info.filename)
    zf.extractall(dest)


def _download(urls, path, progress, done_mb, total_mb):
    from urllib.request import Request, urlopen
    last = None
    for url in urls:
        try:
            req = Request(url, headers={'User-Agent': UA})
            with urlopen(req, timeout=30) as resp, open(path, 'wb') as out:
                size = int(resp.headers.get('Content-Length') or 0)
                got = 0
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    out.write(chunk)
                    got += len(chunk)
                    if progress.iscanceled():
                        raise InterruptedError()
                    part = got / size if size else 0.5
                    pct = int(100 * (done_mb + part * (size / 1048576.0 if size else 1)) / max(total_mb, 1))
                    progress.update(min(pct, 99))
            if not zipfile.is_zipfile(path):
                raise ValueError('δεν είναι zip')
            return True
        except InterruptedError:
            raise
        except Exception as exc:
            last = exc
            menu.log('παιχνίδια: λήψη απέτυχε %s (%s)' % (url, exc), xbmc.LOGWARNING)
    raise IOError(str(last))


def _find(folder, name):
    name = name.lower()
    for base, _dirs, files in os.walk(folder):
        for f in files:
            if f.lower() == name:
                return os.path.join(base, f)
    return None


def ensure_data(game):
    """Επιστρέφει τη διαδρομή του αρχείου που ανοίγει· κατεβάζει τα αρχεία την πρώτη φορά."""
    key = game['data']
    folder = os.path.join(GAMES_DIR, key)
    found = _find(folder, game['find']) if os.path.isfile(os.path.join(folder, '.ok')) else None
    if found:
        return found
    spec = DATA[key]
    tmp_dir = folder + '.tmp'
    shutil.rmtree(tmp_dir, ignore_errors=True)
    os.makedirs(tmp_dir)
    progress = xbmcgui.DialogProgress()
    progress.create('Retro Gaming', t('dl'))
    try:
        done = 0
        for n, urls in enumerate(spec['files']):
            zpath = os.path.join(tmp_dir, 'download%d.zip' % n)
            _download(urls, zpath, progress, done, spec['size'])
            done += os.path.getsize(zpath) / 1048576.0
            with zipfile.ZipFile(zpath) as zf:
                if n == 0:
                    _safe_extract(zf, tmp_dir)
                else:
                    # δεύτερο zip (ECWolf): κρατάμε μόνο το ecwolf.pk3
                    names = [i for i in zf.namelist() if i.lower().endswith('ecwolf.pk3')]
                    if names:
                        with zf.open(names[0]) as src, open(os.path.join(tmp_dir, 'ecwolf.pk3'), 'wb') as dst:
                            shutil.copyfileobj(src, dst)
            os.remove(zpath)
        progress.update(100)
    except InterruptedError:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        return None
    except Exception as exc:
        menu.log('παιχνίδια: %s απέτυχε (%s)' % (key, exc), xbmc.LOGWARNING)
        shutil.rmtree(tmp_dir, ignore_errors=True)
        xbmcgui.Dialog().ok('Retro Gaming', t('dlfail'))
        return None
    finally:
        progress.close()
    if not _find(tmp_dir, game['find']):
        menu.log('παιχνίδια: δεν βρέθηκε το %s στα αρχεία του %s' % (game['find'], key), xbmc.LOGWARNING)
        shutil.rmtree(tmp_dir, ignore_errors=True)
        xbmcgui.Dialog().ok('Retro Gaming', t('nofile'))
        return None
    with open(os.path.join(tmp_dir, '.ok'), 'w') as fh:
        fh.write(str(int(time.time())))
    shutil.rmtree(folder, ignore_errors=True)
    os.rename(tmp_dir, folder)
    return _find(folder, game['find'])


def _prepare(game, path):
    """Μικρές προετοιμασίες πριν το άνοιγμα. Επιστρέφει το αρχείο που δίνεται στον πυρήνα."""
    folder = os.path.dirname(path)
    if game['id'] == 'wolf3d':
        # Το ECWolf θέλει το ecwolf.pk3: δίπλα στα αρχεία του παιχνιδιού και στον φάκελο system του πυρήνα.
        pk3 = os.path.join(GAMES_DIR, 'wolf3d', 'ecwolf.pk3')
        if os.path.isfile(pk3):
            targets = [folder, xbmcvfs.translatePath('special://home/addons/%s/resources/system' % game['core'])]
            for dest in targets:
                try:
                    if not os.path.isdir(dest):
                        os.makedirs(dest)
                    if not os.path.isfile(os.path.join(dest, 'ecwolf.pk3')):
                        shutil.copyfile(pk3, os.path.join(dest, 'ecwolf.pk3'))
                except OSError as exc:
                    menu.log('παιχνίδια: ecwolf.pk3 → %s (%s)' % (dest, exc), xbmc.LOGWARNING)
    return path


def _ensure_core(game):
    core = game['core']
    if has(core):
        return True
    # εγκατεστημένο αλλά απενεργοποιημένο;
    res = menu.jsonrpc('Addons.GetAddonDetails', {'addonid': core, 'properties': ['enabled']})
    addon = ((res or {}).get('result') or {}).get('addon')
    if addon and addon.get('enabled') is False:
        menu.jsonrpc('Addons.SetAddonEnabled', {'addonid': core, 'enabled': True})
        xbmc.sleep(500)
        return has(core)
    # δεν υπάρχει: το Kodi ρωτά «Να εγκατασταθεί;» και το κατεβάζει από το επίσημο αποθετήριο
    xbmcgui.Dialog().notification('Retro Gaming', t('install'), xbmcgui.NOTIFICATION_INFO, 3000, False)
    xbmc.executebuiltin('InstallAddon(%s)' % core, True)
    for _ in range(20):
        if has(core):
            return True
        xbmc.sleep(500)
    xbmcgui.Dialog().ok('Retro Gaming', t('nocore'))
    return False


def play(game_id):
    game = BY_ID.get(game_id)
    if not game:
        return
    if not _ensure_core(game):
        return
    if not game.get('data'):
        xbmc.executebuiltin('RunAddon(%s)' % game['core'])
        return
    path = ensure_data(game)
    if not path:
        return
    path = _prepare(game, path)
    menu.log('παιχνίδια: %s με %s (%s)' % (game['label'], game['core'], path))
    xbmc.executebuiltin('RunAddon(%s,"%s")' % (game['core'], path))
