# -*- coding: utf-8 -*-
"""Εφαρμογές Android (Netflix, Magenta TV, Nova TV, SportFMTV, Apple TV, Prime Video, Stremio, Nuvio,
STB Emulator, IPTV Smarters, IPTV) στο «Πρόσθετα».

Φαίνονται ΜΟΝΟ όσες είναι εγκατεστημένες στο box (εξαίρεση: το SportFMTV φαίνεται ΠΑΝΤΑ· αν λείπει,
το κλικ προτείνει εγκατάσταση από το Google Play), από τη λίστα εφαρμογών που δίνει το ίδιο
το Kodi στο Android (androidapp://sources/apps/, AndroidAppDirectory.cpp), με βάση το πακέτο. Ανοίγουν με StartAndroidActivity, έξω από το Kodi·
με το «Πίσω» από την αρχική τους οθόνη το Android γυρνά στο Kodi.
"""
import re

import xbmc

from resources.lib import menu

APP_DIR = 'androidapp://sources/apps/'

# Οι εφαρμογές αναγνωρίζονται από το ΠΑΚΕΤΟ τους (π.χ. com.netflix.ninja).
# Το όνομα της εφαρμογής δεν το δίνει το Kodi στα πρόσθετα: το JSON-RPC Files.GetDirectory
# αρνείται το androidapp:// (FileUtils.cpp, RemoteAccessAllowed) και το xbmcvfs.listdir
# επιστρέφει μόνο το πακέτο. Γι' αυτό η 1.3.19 (με βάση το όνομα) δεν έβρισκε τίποτα.
# (όνομα που δείχνουμε, κανονική έκφραση για το πακέτο[, πακέτο που φαίνεται ΠΑΝΤΑ]),
# με τη σειρά που εμφανίζονται.
SPORTFM_PKG = 'gr.sportfmtv.app'
APPS = (
    ('SportFMTV', re.compile(r'^gr\.sportfmtv\.app$'), SPORTFM_PKG),    # πάντα ορατό και πρώτο
    ('Netflix', re.compile(r'^com\.netflix\.')),                        # ninja (TV), mediaclient (κινητό)
    ('Magenta TV', re.compile(r'^gr\.cosmote\.cosmotetv\.android(tv)?$|magentatv')),
    ('Nova TV', re.compile(r'^uc\.flex\.gr$')),                          # από το nova.gr (πρώην EON)
    ('Apple TV', re.compile(r'^com\.apple\.atve\.')),                    # androidtv.appletv (TV) κ.ά. εκδόσεις
    ('Prime Video', re.compile(r'^com\.amazon\.(amazonvideo\.livingroom|avod\.thirdpartyclient)$')),  # TV / κινητό
    ('Stremio', re.compile(r'stremio')),
    ('Nuvio', re.compile(r'nuvio')),
    ('STB Emulator', re.compile(r'stbemu')),                             # com.mvas.stbemu.pro / .free
    ('IPTV Smarters', re.compile(r'smarters')),                          # com.nst.iptvsmarterstvbox
    ('IPTV', re.compile(r'iptv')),                                       # π.χ. ru.iptvremote.android.iptv
)
# εικονίδιο για εφαρμογή που φαίνεται πάντα αλλά δεν είναι εγκατεστημένη (δικό του δεν υπάρχει στο box)
MISSING_ICON = 'DefaultAddonPVRClient.png'
# πακέτα που ταιριάζουν αλλά δεν είναι εφαρμογές για προβολή
EXCLUDE = re.compile(r'smartremote|launcher|keyboard|widget|myaccount', re.I)


def _packages():
    try:
        import xbmcvfs
        dirs, files = xbmcvfs.listdir(APP_DIR)
        return [p for p in (files + dirs) if p]
    except Exception as exc:
        menu.log('εφαρμογές: δεν διαβάστηκε η λίστα (%s)' % exc, xbmc.LOGWARNING)
        return []


def installed():
    """Λίστα [{'label','pkg','icon'}] με τις εγκατεστημένες εφαρμογές, με τη σειρά του APPS.
    Αν μια εφαρμογή υπάρχει σε δύο εκδόσεις (π.χ. STB Emulator Pro και Free), φαίνονται και οι δύο."""
    if not xbmc.getCondVisibility('System.Platform.Android'):
        return []
    pkgs = sorted(set(_packages()))
    found, used = [], set()
    for entry in APPS:
        name, pattern = entry[0], entry[1]
        hits = [p for p in pkgs if p not in used and pattern.search(p.lower()) and not EXCLUDE.search(p)]
        if not hits and len(entry) > 2:
            # φαίνεται πάντα· δεν είναι εγκατεστημένη → το κλικ προτείνει εγκατάσταση
            found.append({'label': name, 'pkg': entry[2], 'icon': MISSING_ICON, 'missing': True})
            continue
        for p in hits:
            used.add(p)
            label = name
            if len(hits) > 1:
                label = '%s (%s)' % (name, p.rsplit('.', 1)[-1])
            found.append({'label': label, 'pkg': p, 'icon': APP_DIR + p + '.png'})
    return found


def is_installed(pkg):
    pkgs = _packages()
    return not pkgs or pkg in pkgs  # αν δεν διαβάστηκε η λίστα, δοκιμάζουμε να την ανοίξουμε


def start(pkg):
    if not re.match(r'^[A-Za-z0-9_.]+$', pkg or ''):
        return
    if not is_installed(pkg):
        import xbmcgui
        name = next((e[0] for e in APPS if len(e) > 2 and e[2] == pkg), pkg)
        if xbmcgui.Dialog().yesno(name, menu.ADDON.getLocalizedString(30019)):
            xbmc.executebuiltin('StartAndroidActivity(,android.intent.action.VIEW,,market://details?id=%s)' % pkg)
        return
    xbmc.executebuiltin('StartAndroidActivity(%s)' % pkg)


def video_addons():
    """Τα πρόσθετα βίντεο (ό,τι έδειχνε πριν το widget addons://user/xbmc.addon.video)."""
    res = menu.jsonrpc('Addons.GetAddons', {'type': 'xbmc.addon.video', 'enabled': True,
                                            'properties': ['name', 'thumbnail']})
    addons = ((res or {}).get('result') or {}).get('addons') or []
    out = [a for a in addons if a.get('addonid') and a.get('addonid') != 'script.sorbetto.helper']
    return sorted(out, key=lambda a: (a.get('name') or a['addonid']).lower())
