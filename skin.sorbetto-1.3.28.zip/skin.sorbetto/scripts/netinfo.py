# -*- coding: utf-8 -*-
"""Sorbetto: «Σύνδεση & DNS» (Ρυθμίσεις Sorbetto).

Δείχνει δημόσια IP, χώρα, πάροχο, DNS, τοπική IP, router και αν η σύνδεση περνά από VPN.

Είναι μέρος του skin (όχι ξεχωριστό πρόσθετο): το skin το τρέχει με
    RunScript(special://skin/scripts/netinfo.py)
οπότε φτάνει σε όλους με την αυτόματη ενημέρωση του skin, χωρίς εγκατάσταση και χωρίς
να αγγίζει τον βοηθό. Το παράθυρο είναι το xml/script-sorbetto-netinfo.xml του skin
(το Kodi το ψάχνει πρώτα στο ενεργό skin, WindowXML.cpp) και τα κείμενα είναι του skin
(32040–32066, μέσω xbmc.getLocalizedString).

Τρέχει ΜΟΝΟ όταν το πατήσει ο χρήστης· τίποτα στο παρασκήνιο.

Από πού έρχονται τα στοιχεία:
- Τοπική IP, router, DNS 1/2: από το ίδιο το Kodi (Network.* infolabels).
- Δημόσια IP, χώρα, πόλη, πάροχος: από δωρεάν υπηρεσία εντοπισμού IP, μόνο τη στιγμή του
  ελέγχου (ip-api.com, αλλιώς ipwho.is, αλλιώς ipify μόνο για την IP).
- VPN, με δύο ενδείξεις:
  (1) αν η συσκευή δείχνει ενεργό τούνελ VPN (tun0, wg0, ppp0 …). Σε νεότερα Android η λίστα
      δικτύων μπορεί να μη διαβάζεται· τότε μένει «άγνωστο» και μετρά μόνο η (2).
  (2) αν η δημόσια IP του Kodi ανήκει σε υπηρεσία VPN/datacenter ή σε χώρα εκτός Ελλάδας.
  Η (2) είναι η κύρια: μετρά τι βλέπει το internet από το Kodi.
"""
import json
import os
import re
import socket
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

XML = 'script-sorbetto-netinfo.xml'
TIMEOUT = 5
UA = {'User-Agent': 'Sorbetto-NetInfo/1.0'}
TUNNEL_RE = re.compile(r'^(tun|tap|ppp|wg|ipsec|utun|vpn|nordlynx|proton|ovpn)', re.I)
DASH = '—'

COUNTRIES = {
    'GR': 'Ελλάδα', 'CY': 'Κύπρος', 'NL': 'Ολλανδία', 'DE': 'Γερμανία', 'GB': 'Ηνωμένο Βασίλειο',
    'FR': 'Γαλλία', 'IT': 'Ιταλία', 'ES': 'Ισπανία', 'PT': 'Πορτογαλία', 'BE': 'Βέλγιο',
    'CH': 'Ελβετία', 'AT': 'Αυστρία', 'SE': 'Σουηδία', 'NO': 'Νορβηγία', 'DK': 'Δανία',
    'FI': 'Φινλανδία', 'IE': 'Ιρλανδία', 'PL': 'Πολωνία', 'CZ': 'Τσεχία', 'RO': 'Ρουμανία',
    'BG': 'Βουλγαρία', 'HU': 'Ουγγαρία', 'RS': 'Σερβία', 'AL': 'Αλβανία', 'MK': 'Βόρεια Μακεδονία',
    'TR': 'Τουρκία', 'US': 'ΗΠΑ', 'CA': 'Καναδάς', 'AU': 'Αυστραλία', 'JP': 'Ιαπωνία',
    'SG': 'Σιγκαπούρη', 'HK': 'Χονγκ Κονγκ', 'IL': 'Ισραήλ', 'AE': 'Ηνωμένα Αραβικά Εμιράτα',
    'LU': 'Λουξεμβούργο', 'IS': 'Ισλανδία', 'UA': 'Ουκρανία', 'RU': 'Ρωσία', 'BR': 'Βραζιλία',
}

# Ελληνικοί πάροχοι: πώς γράφονται στις βάσεις IP -> πώς τους ξέρει ο χρήστης.
# Η σειρά μετρά: η Vodafone γράφεται «Vodafone-panafon Hellenic Telecommunications Company»,
# γι' αυτό ελέγχεται πριν από τον ΟΤΕ («Hellenic Telecommunications Organisation»).
ISPS = (
    (r'vodafone|panafon|hellas online|\bhol\b', 'Vodafone'),
    (r'hellenic telecommunications organi|\bote\b|cosmote', 'Cosmote'),
    (r'wind hellas|\bnova\b|forthnet', 'Nova'),
    (r'inalan', 'Inalan'),
)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[Sorbetto NetInfo] %s' % msg, level)


def s(string_id):
    """Κείμενο του skin (32040–32066), στη γλώσσα του Kodi."""
    return xbmc.getLocalizedString(string_id)


def is_greek():
    return xbmc.getLanguage(xbmc.ISO_639_1) == 'el'


def _get(url):
    from urllib.request import Request, urlopen
    with urlopen(Request(url, headers=UA), timeout=TIMEOUT) as resp:
        return resp.read().decode('utf-8', 'replace')


def isp_name(raw):
    raw = (raw or '').strip()
    for pattern, name in ISPS:
        if re.search(pattern, raw, re.I):
            return name
    return raw


def country_name(cc, fallback):
    if is_greek():
        return COUNTRIES.get(cc, fallback)
    return fallback


def public_info():
    """Δημόσια IP και τοποθεσία. Επιστρέφει dict· κενό αν δεν απάντησε καμία υπηρεσία."""
    try:
        d = json.loads(_get('http://ip-api.com/json/?fields=status,country,countryCode,city,'
                            'isp,org,proxy,hosting,query'))
        if d.get('status') == 'success' and d.get('query'):
            return {'ip': d['query'], 'cc': (d.get('countryCode') or '').upper(),
                    'country': d.get('country') or '', 'city': d.get('city') or '',
                    'isp': d.get('isp') or d.get('org') or '',
                    'hosting': bool(d.get('hosting') or d.get('proxy'))}
    except Exception as exc:
        log('ip-api: %s' % exc)
    try:
        d = json.loads(_get('https://ipwho.is/'))
        if d.get('success') and d.get('ip'):
            conn = d.get('connection') or {}
            return {'ip': d['ip'], 'cc': (d.get('country_code') or '').upper(),
                    'country': d.get('country') or '', 'city': d.get('city') or '',
                    'isp': conn.get('isp') or conn.get('org') or '', 'hosting': False}
    except Exception as exc:
        log('ipwho.is: %s' % exc)
    try:
        ip = _get('https://api.ipify.org').strip()
        if re.fullmatch(r'[0-9a-fA-F:.]{3,45}', ip):
            return {'ip': ip, 'cc': '', 'country': '', 'city': '', 'isp': '', 'hosting': False}
    except Exception as exc:
        log('ipify: %s' % exc)
    return {}


def tunnel():
    """True: ενεργό τούνελ VPN. False: η λίστα δικτύων διαβάστηκε και δεν έχει. None: δεν διαβάζεται."""
    names = None
    try:
        names = [n for _, n in socket.if_nameindex()]
    except Exception:
        pass
    if names is None:
        try:
            names = os.listdir('/sys/class/net')
        except Exception:
            pass
    if names is None:
        try:
            with open('/proc/net/dev') as f:
                names = [line.split(':', 1)[0].strip() for line in f if ':' in line]
        except Exception:
            pass
    if names is None:
        log('λίστα δικτύων: δεν διαβάζεται σε αυτή τη συσκευή')
        return None
    found = [n for n in names if TUNNEL_RE.match(n)]
    if found:
        log('τούνελ VPN: %s' % ', '.join(found))
    return bool(found)


def _label(name):
    value = xbmc.getInfoLabel(name).strip()
    return '' if value.lower() in ('busy', '0.0.0.0') else value


def local_info():
    return {'local': _label('Network.IPAddress'), 'gateway': _label('Network.GatewayAddress'),
            'dns1': _label('Network.DNS1Address'), 'dns2': _label('Network.DNS2Address')}


def verdict(pub, tun, local):
    """(κατάσταση, τίτλος, υπότιτλος). Κατάσταση: vpn / warn / novpn / unknown."""
    if pub:
        place = country_name(pub['cc'], pub['country']) or s(32051)
        isp = isp_name(pub['isp']) or s(32051)
        if pub['hosting'] or (pub['cc'] and pub['cc'] != 'GR'):
            sub = s(32052) % place
            if tun:
                sub += ' · ' + s(32053)
            return 'vpn', s(32044), sub
        if tun:
            return 'warn', s(32045), s(32054) % isp
        return 'novpn', s(32046), s(32055) % isp
    if not local:
        return 'unknown', s(32047), s(32056)
    if tun:
        return 'vpn', s(32044), s(32053) + ' · ' + s(32057)
    return 'unknown', s(32048), s(32058)


def collect():
    local = local_info()
    tun = tunnel()
    pub = public_info()
    state, head, sub = verdict(pub, tun, local['local'])
    place = ''
    if pub:
        place = country_name(pub['cc'], pub['country'])
        if pub['city']:
            place = (place + ' · ' if place else '') + pub['city']
    log('κατάσταση: %s (τούνελ: %s, χώρα: %s)' % (state, tun, pub.get('cc') or '?'))
    return {
        'state': state, 'head': head, 'sub': sub,
        'ip': pub.get('ip') or DASH, 'place': place or DASH,
        'isp': isp_name(pub.get('isp')) or DASH,
        'dns1': local['dns1'] or DASH, 'dns2': local['dns2'] or DASH,
        'local': local['local'] or DASH, 'gateway': local['gateway'] or DASH,
        'time': time.strftime('%H:%M'),
    }


class NetInfoDialog(xbmcgui.WindowXMLDialog):
    BTN_CHECK = 10
    BTN_CLOSE = 11

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.worker = None

    def onInit(self):
        self.setFocusId(self.BTN_CHECK)
        self.refresh()

    def refresh(self):
        if self.worker and self.worker.is_alive():
            return
        self.setProperty('state', 'checking')
        self.setProperty('head', s(32049))
        self.setProperty('sub', s(32050))
        self.worker = threading.Thread(target=self._work, daemon=True)
        self.worker.start()

    def _work(self):
        try:
            data = collect()
        except Exception as exc:  # ποτέ σφάλμα στην οθόνη του χρήστη
            log('σφάλμα: %s' % exc, xbmc.LOGWARNING)
            data = {'state': 'unknown', 'head': s(32048), 'sub': s(32058)}
        for key, value in data.items():
            self.setProperty(key, value)

    def onClick(self, control_id):
        if control_id == self.BTN_CHECK:
            self.refresh()
        elif control_id == self.BTN_CLOSE:
            self.close()


def run():
    if xbmc.getCondVisibility('Window.IsActive(%s)' % XML):
        return  # ήδη ανοιχτό (διπλό πάτημα)
    dialog = NetInfoDialog(XML, xbmcvfs.translatePath('special://skin/'), 'Default', '1080i')
    dialog.doModal()
    worker = dialog.worker
    del dialog
    if worker and worker.is_alive():
        worker.join(TIMEOUT * 3 + 1)  # να μη μείνει νήμα όταν κλείνει το script


if __name__ == '__main__':
    run()
