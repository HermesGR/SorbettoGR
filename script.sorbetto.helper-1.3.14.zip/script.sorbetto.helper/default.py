# -*- coding: utf-8 -*-
"""Δίνει στο skin λίστες και εκτελεί μικρές εντολές.

Λίστες (το skin τις καλεί ως περιεχόμενο):
    ?action=menu      κουμπιά του μενού, στη γλώσσα του Kodi
    ?action=bgcats    κατηγορίες φόντων (πρώτη: «Όλα»)
    ?action=bgs&cat=N φόντα της κατηγορίας με αριθμό N (κενό = όλα· πρώτο: «Χωρίς φόντο»)
Εντολές (το skin τις καλεί με RunPlugin):
    ?action=theme&name=<θέμα>   αλλαγή χρωμάτων
    ?action=zoom&v=<αριθμός>    μέγεθος γραμμάτων (μεγέθυνση του skin)
    ?action=zoomnext            μέγεθος γραμμάτων: Κανονικό -> Μεγάλο -> Πολύ μεγάλο (σετ γραμματοσειρών)
    ?action=langtoggle          Ελληνικά <-> English
    ?action=sections            ποιες ενότητες φαίνονται στην αρχική (ανά χρήστη)
    ?action=editor              επεξεργασία μενού (μόνο με κλειδί διαχειριστή)
"""
import re
import sys
import time
from urllib.parse import parse_qsl

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import menu

NOOP = 'plugin://script.sorbetto.helper/?action=noop'
ZOOM_ALLOWED = (0, 6, 12)
FONTSETS = ('Default', 'SorbettoLarge', 'SorbettoXLarge')


def add(handle, label, props, art=None):
    li = xbmcgui.ListItem(label=label, offscreen=True)
    li.setProperties(props)
    if art:
        li.setArt(art)
    xbmcplugin.addDirectoryItem(handle, NOOP, li, False)


def list_menu(handle):
    current = menu.lang()
    hidden = menu.load_hidden()
    for item in menu.load()['items']:
        if item['show'] and item['show'] != current:
            continue
        if menu.item_key(item) in hidden and not menu.is_protected(item):
            continue
        add(handle, menu.localized(item, 'label', current), {
            'id': item['id'],
            'action': menu.fix_action(item['action']),
            'icon': item['icon'],
            'widget': item['widget'],
            'widget_label': menu.localized(item, 'widget_label', current),
            'description': menu.localized(item, 'description', current),
        })
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_categories(handle):
    current = menu.lang()
    data = menu.load_backgrounds()
    add(handle, 'Όλα' if current == 'el' else 'All', {'cat': ''})
    for i, c in enumerate(data['categories'], 1):
        add(handle, c['el'] if current == 'el' else c['en'], {'cat': str(i)})
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def list_backgrounds(handle, cat):
    current = menu.lang()
    data = menu.load_backgrounds()
    chosen = xbmc.getInfoLabel('Skin.String(sorbetto_bg)')
    name = ''
    if cat.isdigit() and 0 < int(cat) <= len(data['categories']):
        name = data['categories'][int(cat) - 1]['el']
    add(handle, 'Χωρίς φόντο' if current == 'el' else 'No background',
        {'url': '', 'none': 'true', 'cur': 'true' if not chosen else ''})
    for bg in data['items']:
        if name and bg['cat'] != name:
            continue
        label = bg['cat'] if current == 'el' else (bg['cat_en'] or bg['cat'])
        add(handle, label, {'url': bg['url'], 'cur': 'true' if bg['url'] == chosen else ''},
            {'thumb': bg['thumb'], 'icon': bg['thumb']})
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def set_theme(name):
    if name != 'SKINDEFAULT' and not re.match(r'^[a-z0-9_]{1,40}$', name):
        return
    menu.jsonrpc('Settings.SetSettingValue', {'setting': 'lookandfeel.skincolors', 'value': name})


def set_zoom(value):
    try:
        value = int(value)
    except (TypeError, ValueError):
        return
    if value in ZOOM_ALLOWED:
        menu.jsonrpc('Settings.SetSettingValue', {'setting': 'lookandfeel.skinzoom', 'value': value})


def zoom_next():
    """«Μέγεθος γραμμάτων»: Κανονικό -> Μεγάλο -> Πολύ μεγάλο, με σετ γραμματοσειρών του skin
    (lookandfeel.font). ΔΕΝ χρησιμοποιούμε πια τη «Μεγέθυνση» (skinzoom): μεγεθύνει όλη την
    εικόνα και κόβει τις άκρες της οθόνης."""
    res = menu.jsonrpc('Settings.GetSettingValue', {'setting': 'lookandfeel.font'})
    current = (res.get('result') or {}).get('value', 'Default') if isinstance(res, dict) else 'Default'
    nxt = FONTSETS[(FONTSETS.index(current) + 1) % len(FONTSETS)] if current in FONTSETS else FONTSETS[1]
    menu.jsonrpc('Settings.SetSettingValue', {'setting': 'lookandfeel.font', 'value': nxt})
    menu.undo_old_zoom()


def lang_toggle():
    target = 'resource.language.en_gb' if menu.lang() == 'el' else 'resource.language.el_gr'
    xbmc.executebuiltin('SetGUILanguage(%s)' % target)


def choose_sections():
    """Ο χρήστης διαλέγει ποιες ενότητες φαίνονται στην αρχική. Τίποτα δεν διαγράφεται:
    τα κρυμμένα απλώς δεν μπαίνουν στη λίστα της αρχικής και ξαναφαίνονται με ένα τσεκ."""
    current = menu.lang()
    hidden = menu.load_hidden()
    items = [i for i in menu.load()['items']
             if not menu.is_protected(i) and (not i['show'] or i['show'] == current)]
    if not items:
        xbmcgui.Dialog().ok(menu.ADDON.getLocalizedString(30011), menu.ADDON.getLocalizedString(30013))
        return
    labels = [menu.localized(i, 'label', current) for i in items]
    pre = [n for n, i in enumerate(items) if menu.item_key(i) not in hidden]
    chosen = xbmcgui.Dialog().multiselect(menu.ADDON.getLocalizedString(30011), labels, preselect=pre)
    if chosen is None:  # «Άκυρο»: καμία αλλαγή
        return
    keys = {menu.item_key(i) for i in items}
    shown = {menu.item_key(items[n]) for n in chosen}
    new_hidden = (hidden - keys) | (keys - shown)
    menu.save_hidden(new_hidden)
    # η αρχική ξαναφορτώνει το μενού (αλλάζει η διεύθυνση της λίστας)
    xbmcgui.Window(10000).setProperty(menu.PROP_HIDDEN, str(int(time.time() * 1000)))
    xbmcgui.Dialog().notification('Sorbetto', menu.ADDON.getLocalizedString(30012), time=2500, sound=False)


def main():
    handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get('action', 'menu')

    if action == 'theme':
        set_theme(params.get('name', ''))
    elif action == 'zoom':
        set_zoom(params.get('v'))
    elif action == 'zoomnext':
        zoom_next()
    elif action == 'langtoggle':
        lang_toggle()
    elif action == 'sections':
        choose_sections()
    elif action == 'editor':
        from resources.lib import editor
        editor.run()
    elif handle < 0:
        xbmc.log('[Sorbetto Helper] άγνωστη εντολή: %s' % action, xbmc.LOGDEBUG)
    elif action == 'menu':
        list_menu(handle)
    elif action == 'bgcats':
        list_categories(handle)
    elif action == 'bgs':
        list_backgrounds(handle, params.get('cat', ''))
    else:
        # Τα κουμπιά εκτελούνται από το skin· εδώ δεν κάνουμε τίποτα.
        xbmcplugin.endOfDirectory(handle, succeeded=False)


if __name__ == '__main__':
    main()
